"""
test_v5_case_iii_backfill_hot_cold.py
---------------------------------------
Tests for CASE_III backfill processing:
  HOT lane  (MONTH_DIFF < case3_hot_window_months):
    T1: Single hot backfill - backfilled month and future months patched
    T2: Multiple hot backfills for same account in one run
    T3: Hot backfill with MONTH_DIFF=0 (latest-month scalar patch only)
  COLD lane (MONTH_DIFF >= case3_hot_window_months):
    T4: Cold backfill - correct array rebuild via legacy path
  MIXED:
    T5: Same account has both hot and cold records in same batch
  INVARIANTS:
    - summary arrays always exactly 36 elements after backfill
    - latest arrays always exactly 72 elements
    - Prefix match maintained
    - Slots beyond the backfilled month are NOT overwritten with the backfilled value
"""
from datetime import datetime

from pyspark.sql import functions as F

from v5_contract_utils import (
    HISTORY_COLS,
    LATEST_HISTORY_LEN,
    SUMMARY_HISTORY_LEN,
    assert_equal,
    assert_history_lengths,
    assert_summary_prefix_of_latest,
    assert_true,
    assert_latest_matches_summary_v5,
    history,
    load_v5_module,
    pad_latest_rows,
)
from v5_test_utils import (
    create_spark_session,
    make_config,
    reset_tables,
    write_source_rows,
    write_summary_rows,
    fetch_single_row,
    build_source_row,
    build_summary_row,
)


def _seed_two_months(spark, config, acct, bal_jan, bal_feb, seed_ts):
    """Seed account with Jan and Feb summary rows."""
    jan = build_summary_row(
        acct, "2026-01", seed_ts, balance=bal_jan, actual_payment=bal_jan // 10,
        balance_history=history({0: bal_jan}, SUMMARY_HISTORY_LEN),
        payment_history=history({0: bal_jan // 10}, SUMMARY_HISTORY_LEN),
        credit_history=history({0: 10000}, SUMMARY_HISTORY_LEN),
        past_due_history=history({0: 0}, SUMMARY_HISTORY_LEN),
        dpd_history=history({0: 0}, SUMMARY_HISTORY_LEN),
        rating_history=history({0: "0"}, SUMMARY_HISTORY_LEN),
        asset_history=history({0: "A"}, SUMMARY_HISTORY_LEN),
    )
    feb = build_summary_row(
        acct, "2026-02", seed_ts, balance=bal_feb, actual_payment=bal_feb // 10,
        balance_history=history({0: bal_feb, 1: bal_jan}, SUMMARY_HISTORY_LEN),
        payment_history=history({0: bal_feb // 10, 1: bal_jan // 10}, SUMMARY_HISTORY_LEN),
        credit_history=history({0: 10000, 1: 10000}, SUMMARY_HISTORY_LEN),
        past_due_history=history({0: 0, 1: 0}, SUMMARY_HISTORY_LEN),
        dpd_history=history({0: 0, 1: 0}, SUMMARY_HISTORY_LEN),
        rating_history=history({0: "0", 1: "0"}, SUMMARY_HISTORY_LEN),
        asset_history=history({0: "A", 1: "A"}, SUMMARY_HISTORY_LEN),
    )
    write_summary_rows(spark, config["destination_table"], [jan, feb])
    # latest points at Feb with 72-slot array
    write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([feb]))


def test_v5_case_iii_backfill_hot_cold() -> None:
    module = load_v5_module("_v5_case_iii_backfill")
    spark  = create_spark_session("v5_case_iii_backfill_hot_cold")
    config = make_config("c3_bf", history_length=36, latest_history_window_months=72)
    config["case3_hot_window_months"] = 36

    try:
        # ── T1: Hot backfill – single older month ────────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        seed_ts = datetime(2026, 1, 1)
        bf_ts   = datetime(2026, 3, 1)
        _seed_two_months(spark, config, 6001, bal_jan=5000, bal_feb=4900, seed_ts=seed_ts)
        module.preload_run_table_columns(spark, config)

        # Backfill Jan with corrected value
        write_source_rows(spark, config["source_table"], [
            build_source_row(6001, "2026-01", bf_ts, balance=5100, actual_payment=510),
        ])
        module.run_pipeline(spark, config)

        s_jan = fetch_single_row(spark, config["destination_table"], 6001, "2026-01")
        s_feb = fetch_single_row(spark, config["destination_table"], 6001, "2026-02")
        l_feb = fetch_single_row(spark, config["latest_history_table"], 6001, "2026-02")

        assert_equal(s_jan["balance_am_history"][0], 5100.0, "T1 Jan balance[0] backfilled")
        assert_equal(s_feb["balance_am_history"][1], 5100.0, "T1 Feb balance[1] patched to backfilled Jan")
        assert_equal(l_feb["balance_am_history"][1], 5100.0, "T1 latest Feb balance[1] patched")
        assert_history_lengths(s_feb, l_feb)
        assert_summary_prefix_of_latest(s_feb, l_feb)

        # ── T2: Multiple backfill months for same account ────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        dec = build_summary_row(6002, "2025-12", seed_ts, balance=5500, actual_payment=550,
                                balance_history=history({0: 5500}, SUMMARY_HISTORY_LEN))
        jan = build_summary_row(6002, "2026-01", seed_ts, balance=5400, actual_payment=540,
                                balance_history=history({0: 5400, 1: 5500}, SUMMARY_HISTORY_LEN))
        feb = build_summary_row(6002, "2026-02", seed_ts, balance=5300, actual_payment=530,
                                balance_history=history({0: 5300, 1: 5400, 2: 5500}, SUMMARY_HISTORY_LEN))
        write_summary_rows(spark, config["destination_table"], [dec, jan, feb])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([feb]))
        module.preload_run_table_columns(spark, config)

        # Backfill both Dec and Jan
        write_source_rows(spark, config["source_table"], [
            build_source_row(6002, "2025-12", bf_ts, balance=5600, actual_payment=560),
            build_source_row(6002, "2026-01", bf_ts, balance=5450, actual_payment=545),
        ])
        module.run_pipeline(spark, config)

        s_dec2 = fetch_single_row(spark, config["destination_table"], 6002, "2025-12")
        s_jan2 = fetch_single_row(spark, config["destination_table"], 6002, "2026-01")
        s_feb2 = fetch_single_row(spark, config["destination_table"], 6002, "2026-02")
        l_feb2 = fetch_single_row(spark, config["latest_history_table"], 6002, "2026-02")

        assert_equal(s_dec2["balance_am_history"][0], 5600.0, "T2 Dec balance[0]")
        assert_equal(s_jan2["balance_am_history"][0], 5450.0, "T2 Jan balance[0]")
        assert_equal(s_jan2["balance_am_history"][1], 5600.0, "T2 Jan balance[1] = corrected Dec")
        assert_equal(s_feb2["balance_am_history"][1], 5450.0, "T2 Feb balance[1] = corrected Jan")
        assert_equal(s_feb2["balance_am_history"][2], 5600.0, "T2 Feb balance[2] = corrected Dec")
        assert_history_lengths(s_feb2, l_feb2)
        assert_summary_prefix_of_latest(s_feb2, l_feb2)

        # ── T3: Backfill latest month (MONTH_DIFF=0) – scalar patch only ─────
        reset_tables(spark, config)
        module.cleanup(spark)

        cur_jan = build_summary_row(6003, "2026-01", seed_ts, balance=4000, actual_payment=400,
                                    balance_history=history({0: 4000, 1: 3900}, SUMMARY_HISTORY_LEN))
        write_summary_rows(spark, config["destination_table"], [cur_jan])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([cur_jan]))
        module.preload_run_table_columns(spark, config)

        write_source_rows(spark, config["source_table"], [
            build_source_row(6003, "2026-01", bf_ts, balance=4100, actual_payment=410),
        ])
        module.run_pipeline(spark, config)

        s_cur = fetch_single_row(spark, config["destination_table"], 6003, "2026-01")
        l_cur = fetch_single_row(spark, config["latest_history_table"], 6003, "2026-01")

        # index 0 updated, prior slots unchanged
        assert_equal(s_cur["balance_am_history"][0], 4100.0, "T3 MONTH_DIFF=0 balance[0] updated")
        assert_equal(s_cur["balance_am_history"][1], 3900.0, "T3 MONTH_DIFF=0 balance[1] unchanged")
        assert_history_lengths(s_cur, l_cur)

        # ── T4: Cold backfill (far-back month) ──────────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        anchor = build_summary_row(6004, "2026-01", seed_ts, balance=3000, actual_payment=300)
        write_summary_rows(spark, config["destination_table"], [anchor])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([anchor]))
        module.preload_run_table_columns(spark, config)

        # 2022-01 is > 36 months back from 2026-01 → COLD lane
        write_source_rows(spark, config["source_table"], [
            build_source_row(6004, "2022-01", bf_ts, balance=2000, actual_payment=200),
        ])
        module.run_pipeline(spark, config)

        s_cold = fetch_single_row(spark, config["destination_table"], 6004, "2022-01")
        assert_equal(s_cold["balance_am_history"][0], 2000.0, "T4 cold backfill balance[0]")
        assert_true(len(s_cold["balance_am_history"]) == SUMMARY_HISTORY_LEN,
                    "T4 cold backfill summary array length")

        # ── T5: Global consistency after all runs ────────────────────────────
        assert_latest_matches_summary_v5(
            spark, config["destination_table"], config["latest_history_table"]
        )

        print("[PASS] test_v5_case_iii_backfill_hot_cold")
    finally:
        spark.stop()


if __name__ == "__main__":
    test_v5_case_iii_backfill_hot_cold()
