"""
run_v5_tests_parallel.py
-------------------------
Parallel subprocess runner for the summary_inc_v5 test suite.
Each test runs in its own process for full isolation (separate SparkContext).

Usage:
    python run_v5_tests_parallel.py
    python run_v5_tests_parallel.py --workers 4
    python run_v5_tests_parallel.py --tests test_v5_idempotency test_v5_soft_delete
    V5_PIPELINE_SCRIPT=/path/to/summary_inc_v5.py python run_v5_tests_parallel.py
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path


TESTS_DIR    = Path(__file__).resolve().parent
ARTIFACT_ROOT = TESTS_DIR / "artifacts" / "v5_parallel"

ORDERED_TESTS = [
    "test_v5_module_smoke.py",
    "test_v5_watermark_tracker.py",
    "test_v5_case_end_to_end_smoke.py",
    "test_v5_summary36_latest72_window.py",
    "test_v5_case_i_new_accounts.py",
    "test_v5_case_ii_forward_entries.py",
    "test_v5_case_iii_backfill_hot_cold.py",
    "test_v5_soft_delete.py",
    "test_v5_case_iv_bulk_historical.py",
    "test_v5_idempotency.py",
    "test_v5_latest_summary_consistency.py",
    "test_v5_working_set_context_tables.py",
    "test_v5_lane_routing_and_invariants.py",
    "test_v5_multi_account_mixed_cases.py",
]


def _run_one(name: str, env: dict, run_dir: Path) -> dict:
    log_path = run_dir / f"{name}.log"
    cmd = [sys.executable, str(TESTS_DIR / name)]
    started = time.perf_counter()
    rc = 1
    try:
        with log_path.open("w", encoding="utf-8", newline="\n") as lf:
            proc = subprocess.Popen(
                cmd,
                cwd=str(TESTS_DIR),
                stdout=lf,
                stderr=subprocess.STDOUT,
                env=env,
            )
            rc = proc.wait()
    except Exception as exc:
        log_path.write_text(f"[runner] launch error: {exc}\n", encoding="utf-8")
        rc = 1
    duration = round(time.perf_counter() - started, 2)
    return {
        "test":         name,
        "status":       "PASS" if rc == 0 else "FAIL",
        "exit_code":    rc,
        "duration_sec": duration,
        "log":          str(log_path.relative_to(run_dir)),
    }


def _format_table(results: list[dict]) -> str:
    headers = ["test", "status", "duration_sec"]
    widths  = {h: max(len(h), max(len(str(r[h])) for r in results)) for h in headers}
    sep     = "-+-".join("-" * widths[h] for h in headers)
    hdr     = " | ".join(h.ljust(widths[h]) for h in headers)
    rows    = [" | ".join(str(r[h]).ljust(widths[h]) for h in headers) for r in results]
    return "\n".join([hdr, sep] + rows)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run v5 tests in parallel (one process per test)")
    parser.add_argument("--workers",  type=int, default=0,
                        help="Max parallel workers (default: CPU count)")
    parser.add_argument("--tests",    nargs="*",
                        help="Specific test files to run")
    parser.add_argument("--pipeline-script", default="",
                        help="Path to summary_inc_v5.py")
    args = parser.parse_args(argv)

    if args.tests:
        tests = [t if t.endswith(".py") else f"{t}.py" for t in args.tests]
    else:
        tests = ORDERED_TESTS

    missing = [t for t in tests if not (TESTS_DIR / t).exists()]
    if missing:
        print(f"ERROR: missing test files: {missing}", file=sys.stderr)
        return 1

    workers = args.workers or max(1, min(len(tests), os.cpu_count() or 1))

    run_id  = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_dir = ARTIFACT_ROOT / f"run_{run_id}"
    run_dir.mkdir(parents=True, exist_ok=True)

    env = dict(os.environ)
    env["PYTHONUNBUFFERED"] = "1"
    if args.pipeline_script:
        env["V5_PIPELINE_SCRIPT"] = args.pipeline_script
    elif not env.get("V5_PIPELINE_SCRIPT"):
        co = TESTS_DIR / "summary_inc_v5.py"
        if co.exists():
            env["V5_PIPELINE_SCRIPT"] = str(co)

    print(f"=== v5 parallel runner  run={run_id}  workers={workers}  tests={len(tests)} ===")

    results: list[dict] = []
    with cf.ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(_run_one, t, env, run_dir): t for t in tests}
        for future in cf.as_completed(futures):
            try:
                r = future.result()
            except Exception as exc:
                r = {
                    "test":         futures[future],
                    "status":       "FAIL",
                    "exit_code":    1,
                    "duration_sec": 0.0,
                    "log":          f"unhandled error: {exc}",
                }
            results.append(r)
            tag = "✓" if r["status"] == "PASS" else "✗"
            print(f"  {tag} {r['test']:50s} {r['status']}  ({r['duration_sec']}s)")

    results.sort(key=lambda r: r["test"])

    passed  = sum(1 for r in results if r["status"] == "PASS")
    failed  = len(results) - passed
    overall = "PASS" if failed == 0 else "FAIL"

    print()
    print(_format_table(results))
    print(f"\nTOTAL={len(results)}  PASS={passed}  FAIL={failed}  [{overall}]")
    print(f"artifacts: {run_dir}")

    payload = {
        "run_id": run_id, "run_dir": str(run_dir),
        "total": len(results), "passed": passed, "failed": failed,
        "overall_status": overall, "results": results,
    }
    (run_dir / "summary.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
