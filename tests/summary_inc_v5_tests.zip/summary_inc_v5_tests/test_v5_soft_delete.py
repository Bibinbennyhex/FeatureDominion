"""
test_v5_soft_delete.py
-----------------------
Tests for soft-delete (CASE_III with _is_soft_delete=True):
  T1: Soft-delete an older month (code "1") → soft_del_cd set, future positions nullified
  T2: Soft-delete with code "4" → same outcome as code "1"
  T3: Soft-delete the latest month → latest_summary reconstructed from previous non-deleted row
  T4: Soft-delete with null payload fields → delete flagged, scalar arrays not corrupted
  T5: Multi-delete in one batch → all targeted months flagged, all future positions nullified
  T6: Re-insert after soft-delete → row comes back, arrays correct
  T7: Soft-delete of month not in summary → silent no-op (no crash)
"""
from datetime import datetime

from v5_contract_utils import (
    DELETE_CODES,
    HISTORY_COLS,
    LATEST_HISTORY_LEN,
    SUMMARY_HISTORY_LEN,
    assert_equal,
    assert_history_lengths,
    assert_true,
    assert_latest_matches_summary_v5,
    history,
    load_v5_module,
    pad_latest_rows,
)
from v5_test_utils import (
    create_spark_session,
    make_config,
    reset_tables,
    write_source_rows,
    write_summary_rows,
    fetch_single_row,
    fetch_rows,
    build_source_row,
    build_summary_row,
)


def _seed_jan_feb(spark, config, acct, seed_ts):
    """Seed Jan + Feb rows; latest_summary on Feb."""
    jan_bal, feb_bal = 5000.0, 4900.0
    jan = build_summary_row(acct, "2026-01", seed_ts, balance=jan_bal, actual_payment=500,
                            balance_history=history({0: jan_bal}, SUMMARY_HISTORY_LEN))
    feb = build_summary_row(acct, "2026-02", seed_ts, balance=feb_bal, actual_payment=490,
                            balance_history=history({0: feb_bal, 1: jan_bal}, SUMMARY_HISTORY_LEN))
    write_summary_rows(spark, config["destination_table"], [jan, feb])
    write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([feb]))
    return jan_bal, feb_bal


def test_v5_soft_delete() -> None:
    module = load_v5_module("_v5_soft_delete")
    spark  = create_spark_session("v5_soft_delete")
    config = make_config("soft_del")

    try:
        for delete_code in DELETE_CODES:
            # ── T1/T2: Delete older month → soft_del_cd set, future nullified ──
            reset_tables(spark, config)
            module.cleanup(spark)

            seed_ts = datetime(2026, 1, 1)
            del_ts  = datetime(2026, 3, 1)
            jan_bal, feb_bal = _seed_jan_feb(spark, config, 7001, seed_ts)
            module.preload_run_table_columns(spark, config)

            write_source_rows(spark, config["source_table"], [
                build_source_row(7001, "2026-01", del_ts, balance=None, actual_payment=None,
                                 soft_del_cd=delete_code),
            ])
            module.run_pipeline(spark, config)

            s_jan = fetch_single_row(spark, config["destination_table"], 7001, "2026-01")
            s_feb = fetch_single_row(spark, config["destination_table"], 7001, "2026-02")

            assert_equal(s_jan["soft_del_cd"], delete_code,
                         f"code={delete_code} soft_del_cd set on deleted month")

            # Future row's position [1] (= Jan) must be None
            for col in HISTORY_COLS:
                assert_true(
                    s_feb[col][1] is None,
                    f"code={delete_code} {col}[1] in Feb must be nullified after Jan delete"
                )

        # ── T3: Delete latest month → latest_summary reconstructed ───────────
        reset_tables(spark, config)
        module.cleanup(spark)

        seed_ts = datetime(2026, 1, 1)
        del_ts  = datetime(2026, 3, 1)
        _seed_jan_feb(spark, config, 7002, seed_ts)
        module.preload_run_table_columns(spark, config)

        # Delete Feb (latest month)
        write_source_rows(spark, config["source_table"], [
            build_source_row(7002, "2026-02", del_ts, balance=None, actual_payment=None,
                             soft_del_cd="1"),
        ])
        module.run_pipeline(spark, config)

        # latest_summary should now reflect Jan (the non-deleted row)
        l_after = fetch_single_row(spark, config["latest_history_table"], 7002, "2026-01")
        assert_equal(l_after["rpt_as_of_mo"], "2026-01",
                     "T3 latest_summary reconstructed to prior non-deleted month")

        # ── T4: Delete with null scalar payload → arrays not corrupted ────────
        reset_tables(spark, config)
        module.cleanup(spark)

        _seed_jan_feb(spark, config, 7003, seed_ts)
        # Record existing state before delete
        pre_jan = fetch_single_row(spark, config["destination_table"], 7003, "2026-01")
        module.preload_run_table_columns(spark, config)

        write_source_rows(spark, config["source_table"], [
            build_source_row(7003, "2026-01", del_ts, balance=None, actual_payment=None,
                             soft_del_cd="4"),
        ])
        module.run_pipeline(spark, config)

        post_jan = fetch_single_row(spark, config["destination_table"], 7003, "2026-01")
        assert_equal(post_jan["soft_del_cd"], "4", "T4 soft_del_cd set")
        # Arrays on the deleted row itself should not be overwritten by null payload
        for col in HISTORY_COLS:
            assert_equal(list(post_jan[col]), list(pre_jan[col]),
                         f"T4 {col} arrays unchanged on delete row itself")

        # ── T5: Multi-delete in one batch ─────────────────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        seed_ts = datetime(2026, 1, 1)
        del_ts  = datetime(2026, 4, 1)
        dec = build_summary_row(7004, "2025-12", seed_ts, balance=6000, actual_payment=600,
                                balance_history=history({0: 6000}, SUMMARY_HISTORY_LEN))
        jan = build_summary_row(7004, "2026-01", seed_ts, balance=5900, actual_payment=590,
                                balance_history=history({0: 5900, 1: 6000}, SUMMARY_HISTORY_LEN))
        feb = build_summary_row(7004, "2026-02", seed_ts, balance=5800, actual_payment=580,
                                balance_history=history({0: 5800, 1: 5900, 2: 6000}, SUMMARY_HISTORY_LEN))
        write_summary_rows(spark, config["destination_table"], [dec, jan, feb])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([feb]))
        module.preload_run_table_columns(spark, config)

        write_source_rows(spark, config["source_table"], [
            build_source_row(7004, "2025-12", del_ts, soft_del_cd="1"),
            build_source_row(7004, "2026-01", del_ts, soft_del_cd="1"),
        ])
        module.run_pipeline(spark, config)

        s_dec  = fetch_single_row(spark, config["destination_table"], 7004, "2025-12")
        s_jan5 = fetch_single_row(spark, config["destination_table"], 7004, "2026-01")
        s_feb5 = fetch_single_row(spark, config["destination_table"], 7004, "2026-02")

        assert_equal(s_dec["soft_del_cd"],  "1", "T5 Dec soft_del_cd")
        assert_equal(s_jan5["soft_del_cd"], "1", "T5 Jan soft_del_cd")
        # Feb history at position [1] (Jan) and [2] (Dec) must be None
        assert_true(s_feb5["balance_am_history"][1] is None, "T5 Feb[1] nullified")
        assert_true(s_feb5["balance_am_history"][2] is None, "T5 Feb[2] nullified")

        # ── T6: Re-insert after soft-delete ───────────────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        _seed_jan_feb(spark, config, 7005, seed_ts)
        module.preload_run_table_columns(spark, config)

        write_source_rows(spark, config["source_table"], [
            build_source_row(7005, "2026-01", del_ts, soft_del_cd="1"),
        ])
        module.run_pipeline(spark, config)

        # Re-insert same month (no soft_del_cd) with newer ts
        reinstate_ts = datetime(2026, 5, 1)
        write_source_rows(spark, config["source_table"], [
            build_source_row(7005, "2026-01", reinstate_ts, balance=5050, actual_payment=505),
        ])
        module.run_pipeline(spark, config)

        s_reinstate = fetch_single_row(spark, config["destination_table"], 7005, "2026-01")
        assert_true(
            s_reinstate.get("soft_del_cd") is None or s_reinstate.get("soft_del_cd") not in DELETE_CODES,
            "T6 re-inserted row should not have soft_del_cd set"
        )
        assert_equal(s_reinstate["balance_am_history"][0], 5050.0, "T6 re-inserted balance")

        # ── T7: Delete month not in summary → no crash ────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        jan_only = build_summary_row(7006, "2026-01", seed_ts, balance=4000)
        write_summary_rows(spark, config["destination_table"], [jan_only])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([jan_only]))
        module.preload_run_table_columns(spark, config)

        # Delete 2025-06 which does not exist in summary
        write_source_rows(spark, config["source_table"], [
            build_source_row(7006, "2025-06", del_ts, soft_del_cd="1"),
        ])
        module.run_pipeline(spark, config)  # must not raise

        print("[PASS] test_v5_soft_delete")
    finally:
        spark.stop()


if __name__ == "__main__":
    test_v5_soft_delete()
