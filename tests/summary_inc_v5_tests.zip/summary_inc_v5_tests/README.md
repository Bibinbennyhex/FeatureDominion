# summary_inc_v5 — Test Suite

Complete test suite for `summary_inc_v5.py`. Adapted and extended from the v4 test suite.

---

## File layout

```
summary_inc_v5_tests/
├── v5_contract_utils.py                  # Core assertions, module loader, array helpers
├── v5_test_utils.py                      # Spark session, row builders, table helpers, config factory
│
├── test_v5_module_smoke.py               # Syntax, symbol, and constant checks (no Spark needed for helpers)
├── test_v5_watermark_tracker.py          # Tracker lifecycle, validate_config, helper unit tests
├── test_v5_case_end_to_end_smoke.py      # 3-run pipeline smoke (Case I → II → III)
├── test_v5_summary36_latest72_window.py  # 36/72 array-length contract + sentinel preservation
├── test_v5_case_i_new_accounts.py        # Case I: single, multi-account, trailing-null, grid col
├── test_v5_case_ii_forward_entries.py    # Case II: single, skip-month, multi-month, dedup
├── test_v5_case_iii_backfill_hot_cold.py # Case III backfill: HOT, COLD, MONTH_DIFF=0
├── test_v5_soft_delete.py                # Soft-delete: codes 1&4, future nullify, latest reconstruct
├── test_v5_case_iv_bulk_historical.py    # Case IV: 48-month load, partial, forward chain, multi-acct
├── test_v5_idempotency.py                # Re-run idempotency for all 4 cases + mixed batch
├── test_v5_latest_summary_consistency.py # latest_summary correctness across all scenarios
├── test_v5_working_set_context_tables.py # Working-set materialization scoping
├── test_v5_lane_routing_and_invariants.py# Lane routing, null updates, grid cols, base_ts, classification
├── test_v5_multi_account_mixed_cases.py  # Mixed batch, consecutive/non-contiguous backfill, edge cases
│
├── run_v5_tests_sequential.py            # Sequential runner (recommended for CI)
└── run_v5_tests_parallel.py              # Parallel subprocess runner (faster on multi-core)
```

---

## Setup

### 1. Place the pipeline file

Either:
- Copy `summary_inc_v5.py` into this directory, **or**
- Set `V5_PIPELINE_SCRIPT=/absolute/path/to/summary_inc_v5.py`

### 2. Install dependencies

```bash
pip install pyspark
# Iceberg jars must be on the Spark classpath — set via spark-defaults.conf or PYSPARK_SUBMIT_ARGS
```

### 3. Run

```bash
# All tests, sequential (recommended):
python run_v5_tests_sequential.py

# Specific tests only:
python run_v5_tests_sequential.py --tests test_v5_module_smoke test_v5_idempotency

# Parallel (faster, but Spark sessions compete for memory):
python run_v5_tests_parallel.py --workers 4

# With explicit pipeline path:
V5_PIPELINE_SCRIPT=/path/to/summary_inc_v5.py python run_v5_tests_sequential.py
```

---

## What is tested

| Area | Tests | Notes |
|---|---|---|
| Module integrity | `test_v5_module_smoke` | Syntax, required symbols, v5 lane-split presence |
| Config validation | `test_v5_watermark_tracker` | `validate_config` rejects missing fields |
| Pure helpers | `test_v5_watermark_tracker` | `_to_int`, `_safe_min`, `_int_to_partition`, `month_to_int_expr`, `build_month_chunks` |
| **Case I** new accounts | `test_v5_case_i_new_accounts` | Single, multi-acct, trailing nulls, grid col |
| **Case II** forward | `test_v5_case_ii_forward_entries` | Single, skip-month, multi-month, dedup |
| **Case III** backfill HOT | `test_v5_case_iii_backfill_hot_cold` | Within hot window |
| **Case III** backfill COLD | `test_v5_case_iii_backfill_hot_cold` | Beyond hot window |
| **Case III** MONTH_DIFF=0 | `test_v5_case_iii_backfill_hot_cold` | Scalar patch only |
| **Case IV** bulk historical | `test_v5_case_iv_bulk_historical` | 48-month load, partial fill, multi-acct |
| Soft-delete codes 1 & 4 | `test_v5_soft_delete` | Flag, future nullify, latest reconstruct |
| Soft-delete null payload | `test_v5_soft_delete` | Arrays not overwritten |
| Soft-delete re-insert | `test_v5_soft_delete` | Row comes back correctly |
| 36/72 length contract | `test_v5_summary36_latest72_window` | Every history col, every case type |
| Sentinel preservation | `test_v5_summary36_latest72_window` | Slots 36-71 not destroyed by summary ops |
| Idempotency | `test_v5_idempotency` | All 4 cases + mixed batch, byte-for-byte |
| latest_summary consistency | `test_v5_latest_summary_consistency` | Correct row, no dupes, after every case |
| Working-set scoping | `test_v5_working_set_context_tables` | Classified-only latest; full-history case3 |
| Lane routing HOT/COLD/MIXED | `test_v5_lane_routing_and_invariants` | MONTH_DIFF boundary, mixed account |
| Null payload updates | `test_v5_lane_routing_and_invariants` | Backfill, forward, soft-delete |
| Grid columns | `test_v5_lane_routing_and_invariants` | After Case II, III, placeholder |
| base_ts propagation | `test_v5_lane_routing_and_invariants` | GREATEST applied in summary + latest |
| Classification correctness | `test_v5_lane_routing_and_invariants` | All 4 case types, `_is_soft_delete` flag |
| Mixed-case batch | `test_v5_multi_account_mixed_cases` | I+II+III+IV in one run |
| Consecutive backfill | `test_v5_multi_account_mixed_cases` | Same month backfilled twice |
| Non-contiguous backfill | `test_v5_multi_account_mixed_cases` | Gap months untouched |
| Zero-row source | `test_v5_multi_account_mixed_cases` | Graceful no-op |
| Boundary slot [35] | `test_v5_multi_account_mixed_cases` | 36-month array boundary |

---

## Key differences from v4 test suite

| Aspect | v4 | v5 |
|---|---|---|
| Module loader | `v4_pipeline_selector.py` + `V4_PIPELINE_SCRIPT` | `V5_PIPELINE_SCRIPT` env / co-location |
| Case III entry point | `process_case_iii(...)` | `categorize_updates(...)` → dispatches to `_hot`/`_cold`/`_mixed` |
| Temp tables | Parquet / arbitrary | Iceberg (`write_case_table_bucketed`) |
| `HISTORY_LENGTH` constant | 36 | 36 (unchanged) |
| `LATEST_HISTORY_MIN_LEN_V4` | 72 | 72 (same constant name in v5) |
| `SOFT_DELETE_CODES` | `("1","4")` | `("1","4")` (unchanged) |
| Working-set feature flags | Optional | `enable_case3_hot_cold_split`, `use_working_set_*` |
| `preload_run_table_columns` | Required before classification | Required — called explicitly in tests |
