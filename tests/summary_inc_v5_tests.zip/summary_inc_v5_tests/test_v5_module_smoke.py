"""
test_v5_module_smoke.py
-----------------------
Validates that summary_inc_v5.py:
  - is syntactically valid Python
  - exports all required public symbols
  - has the v5 lane-split Case III entry points (not the legacy single entry point)
  - exposes correct constant values
"""
import py_compile
import sys
from pathlib import Path

from v5_contract_utils import load_v5_module, resolve_v5_path


def test_v5_module_smoke() -> None:
    path = resolve_v5_path()
    # 1. Syntax check
    py_compile.compile(str(path), doraise=True)

    content = path.read_text(encoding="utf-8")

    # 2. Required function symbols
    required_fns = [
        "run_pipeline",
        "cleanup",
        "load_and_classify_accounts",
        "process_case_i",
        "process_case_ii",
        "process_case_iv",
        "categorize_updates",
        "write_backfill_results",
        "write_forward_results",
        "materialize_working_set_context_tables",
        "preload_run_table_columns",
        "ensure_soft_delete_columns",
        "get_summary_history_len",
        "get_latest_history_len",
        "month_to_int_expr",
        "build_month_chunks",
    ]
    missing = [fn for fn in required_fns if f"def {fn}(" not in content]
    assert not missing, f"Missing required symbols in v5: {missing}"

    # 3. v5 must have the split lane handlers
    split_symbols = [
        "def process_case_iii_hot(",
        "def process_case_iii_cold(",
        "def process_case_iii_mixed(",
    ]
    missing_split = [s for s in split_symbols if s not in content]
    assert not missing_split, f"v5 is missing lane-split Case III handlers: {missing_split}"

    # 4. Hot/cold private helpers must exist
    for priv in ("_backfill_hot", "_backfill_legacy", "_softdelete_hot", "_softdelete_legacy"):
        assert f"def {priv}(" in content, f"Missing private helper: {priv}"

    # 5. v5 constants
    mod = load_v5_module("_v5_smoke_mod")
    assert getattr(mod, "HISTORY_LENGTH", None) == 36, "HISTORY_LENGTH constant must be 36"
    assert getattr(mod, "LATEST_HISTORY_MIN_LEN_V4", None) == 72, "LATEST_HISTORY_MIN_LEN_V4 must be 72"
    assert set(getattr(mod, "SOFT_DELETE_CODES", [])) == {"1", "4"}, "SOFT_DELETE_CODES must be {1, 4}"

    # 6. Working-set table constants exist
    for attr in (
        "WORKSET_LATEST_SUMMARY_TABLE",
        "WORKSET_SUMMARY_CASE3_TABLE",
        "CASE3_LATEST_MONTH_PATCH_TABLE",
        "CASE3D_LATEST_HISTORY_CONTEXT_PATCH_TABLE",
    ):
        assert hasattr(mod, attr), f"Missing constant: {attr}"

    print("[PASS] test_v5_module_smoke")


if __name__ == "__main__":
    test_v5_module_smoke()
