"""
test_v5_case_ii_forward_entries.py
------------------------------------
Tests for CASE_II (forward / newer-than-latest month entries):
  1. Single forward month - arrays shift correctly (new value at [0], prior at [1])
  2. Multiple forward months in one batch (MONTH_DIFF > 1) - gap handling
  3. latest_summary updated to new max month
  4. Forward entry where summary array was partially filled
  5. latest_summary array tail (indices 36-71) preserved correctly
  6. Dedup: duplicate (key, month) in source → latest ts wins
"""
from datetime import datetime

from pyspark.sql import functions as F

from v5_contract_utils import (
    HISTORY_COLS,
    LATEST_HISTORY_LEN,
    SUMMARY_HISTORY_LEN,
    assert_equal,
    assert_history_lengths,
    assert_summary_prefix_of_latest,
    assert_true,
    assert_latest_matches_summary_v5,
    history,
    load_v5_module,
    pad_latest_rows,
)
from v5_test_utils import (
    create_spark_session,
    make_config,
    reset_tables,
    write_source_rows,
    write_summary_rows,
    fetch_single_row,
    build_source_row,
    build_summary_row,
)


def test_v5_case_ii_forward_entries() -> None:
    module = load_v5_module("_v5_case_ii")
    spark  = create_spark_session("v5_case_ii_forward_entries")
    config = make_config("case_ii")

    try:
        # ── T1: Single forward month ──────────────────────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        seed_ts = datetime(2026, 1, 1)
        seed_row = build_summary_row(
            5001, "2026-01", seed_ts, balance=6000, actual_payment=300,
            balance_history=history({0: 6000, 1: 5800}, SUMMARY_HISTORY_LEN),
        )
        write_summary_rows(spark, config["destination_table"], [seed_row])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([seed_row]))
        module.preload_run_table_columns(spark, config)

        fwd_ts = datetime(2026, 2, 5)
        write_source_rows(spark, config["source_table"], [
            build_source_row(5001, "2026-02", fwd_ts, balance=5900, actual_payment=320),
        ])
        module.run_pipeline(spark, config)

        s_feb = fetch_single_row(spark, config["destination_table"], 5001, "2026-02")
        l_feb = fetch_single_row(spark, config["latest_history_table"], 5001, "2026-02")

        assert_equal(s_feb["balance_am_history"][0], 5900.0, "T1 balance[0] = current")
        assert_equal(s_feb["balance_am_history"][1], 6000.0, "T1 balance[1] = prior Jan")
        assert_equal(s_feb["balance_am_history"][2], 5800.0, "T1 balance[2] = prior-prior")
        assert_history_lengths(s_feb, l_feb)
        assert_summary_prefix_of_latest(s_feb, l_feb)

        # latest_summary must be on 2026-02 now
        assert_equal(l_feb["rpt_as_of_mo"], "2026-02", "T1 latest rpt_as_of_mo advanced")

        # ── T2: Skip-month forward (MONTH_DIFF > 1) ──────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        seed_row2 = build_summary_row(5002, "2026-01", seed_ts, balance=7000, actual_payment=350)
        write_summary_rows(spark, config["destination_table"], [seed_row2])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([seed_row2]))
        module.preload_run_table_columns(spark, config)

        # Jump to March (skip February)
        write_source_rows(spark, config["source_table"], [
            build_source_row(5002, "2026-03", fwd_ts, balance=6800, actual_payment=310),
        ])
        module.run_pipeline(spark, config)

        s_mar = fetch_single_row(spark, config["destination_table"], 5002, "2026-03")
        l_mar = fetch_single_row(spark, config["latest_history_table"], 5002, "2026-03")

        assert_equal(s_mar["balance_am_history"][0], 6800.0, "T2 balance[0]")
        # index 1 = Feb (no data) => None
        assert_true(s_mar["balance_am_history"][1] is None,
                    "T2 balance[1] (skipped Feb) should be None")
        # index 2 = Jan
        assert_equal(s_mar["balance_am_history"][2], 7000.0, "T2 balance[2] = Jan value")
        assert_history_lengths(s_mar, l_mar)
        assert_summary_prefix_of_latest(s_mar, l_mar)

        # ── T3: Multiple forward months in same batch ─────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        seed_row3 = build_summary_row(5003, "2026-01", seed_ts, balance=8000, actual_payment=400)
        write_summary_rows(spark, config["destination_table"], [seed_row3])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([seed_row3]))
        module.preload_run_table_columns(spark, config)

        write_source_rows(spark, config["source_table"], [
            build_source_row(5003, "2026-02", fwd_ts, balance=7900, actual_payment=390),
            build_source_row(5003, "2026-03", fwd_ts, balance=7800, actual_payment=380),
        ])
        module.run_pipeline(spark, config)

        s3_feb = fetch_single_row(spark, config["destination_table"], 5003, "2026-02")
        s3_mar = fetch_single_row(spark, config["destination_table"], 5003, "2026-03")
        l3_mar = fetch_single_row(spark, config["latest_history_table"], 5003, "2026-03")

        assert_equal(s3_feb["balance_am_history"][0], 7900.0, "T3 Feb balance[0]")
        assert_equal(s3_feb["balance_am_history"][1], 8000.0, "T3 Feb balance[1] = Jan")
        assert_equal(s3_mar["balance_am_history"][0], 7800.0, "T3 Mar balance[0]")
        assert_equal(s3_mar["balance_am_history"][1], 7900.0, "T3 Mar balance[1] = Feb")
        assert_equal(s3_mar["balance_am_history"][2], 8000.0, "T3 Mar balance[2] = Jan")
        assert_history_lengths(s3_mar, l3_mar)
        assert_summary_prefix_of_latest(s3_mar, l3_mar)

        # ── T4: Dedup - duplicate source rows → latest ts wins ────────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        seed_row4 = build_summary_row(5004, "2026-01", seed_ts, balance=9000, actual_payment=450)
        write_summary_rows(spark, config["destination_table"], [seed_row4])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([seed_row4]))
        module.preload_run_table_columns(spark, config)

        ts_old = datetime(2026, 2, 1)
        ts_new = datetime(2026, 2, 2)
        write_source_rows(spark, config["source_table"], [
            build_source_row(5004, "2026-02", ts_old, balance=8800, actual_payment=440),
            build_source_row(5004, "2026-02", ts_new, balance=9100, actual_payment=455),
        ])
        module.run_pipeline(spark, config)

        s4_feb = fetch_single_row(spark, config["destination_table"], 5004, "2026-02")
        # newer ts should win
        assert_equal(s4_feb["balance_am_history"][0], 9100.0, "T4 dedup: newer ts balance wins")

        assert_latest_matches_summary_v5(spark, config["destination_table"], config["latest_history_table"])
        print("[PASS] test_v5_case_ii_forward_entries")
    finally:
        spark.stop()


if __name__ == "__main__":
    test_v5_case_ii_forward_entries()
