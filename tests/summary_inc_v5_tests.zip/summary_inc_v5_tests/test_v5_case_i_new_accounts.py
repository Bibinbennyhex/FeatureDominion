"""
test_v5_case_i_new_accounts.py
--------------------------------
Tests for CASE_I (brand-new accounts):
  1. Single new account - arrays built correctly
  2. Multiple new accounts in same batch
  3. New account + anchor account (ensures classification ignores anchor)
  4. Case I arrays: index-0 = current value, all other slots = None
  5. latest_summary row created with 72-slot arrays
  6. Grid column (payment_history_grid) derived correctly
"""
from datetime import datetime

from pyspark.sql import functions as F

from v5_contract_utils import (
    HISTORY_COLS,
    LATEST_HISTORY_LEN,
    SUMMARY_HISTORY_LEN,
    assert_equal,
    assert_history_lengths,
    assert_summary_prefix_of_latest,
    assert_true,
    assert_latest_matches_summary_v5,
    load_v5_module,
    pad_latest_rows,
)
from v5_test_utils import (
    create_spark_session,
    make_config,
    reset_tables,
    write_source_rows,
    write_summary_rows,
    fetch_single_row,
    fetch_rows,
    build_source_row,
    build_summary_row,
)


def test_v5_case_i_new_accounts() -> None:
    module = load_v5_module("_v5_case_i")
    spark  = create_spark_session("v5_case_i_new_accounts")
    config = make_config("case_i")

    try:
        reset_tables(spark, config)
        module.cleanup(spark)
        module.preload_run_table_columns(spark, config)

        ts = datetime(2026, 3, 1)

        # ── T1: Single new account ────────────────────────────────────────────
        write_source_rows(spark, config["source_table"], [
            build_source_row(2001, "2026-01", ts, balance=8000, actual_payment=400,
                             payment_rating="1", asset_class="B"),
        ])
        module.run_pipeline(spark, config)

        s = fetch_single_row(spark, config["destination_table"], 2001, "2026-01")
        l = fetch_single_row(spark, config["latest_history_table"], 2001, "2026-01")

        assert_history_lengths(s, l)
        assert_summary_prefix_of_latest(s, l)
        assert_equal(s["balance_am_history"][0],         8000.0, "T1 balance[0]")
        assert_equal(s["actual_payment_am_history"][0],  400.0,  "T1 payment[0]")
        assert_equal(s["payment_rating_cd_history"][0],  "1",    "T1 rating[0]")
        assert_equal(s["asset_class_cd_4in_history"][0], "B",    "T1 asset[0]")

        # All history slots after index 0 must be None for a fresh new-account row
        for col in HISTORY_COLS:
            trailing = list(s[col][1:])
            assert_true(
                all(v is None for v in trailing),
                f"T1 Case I {col}: slots [1:] must all be None, got {trailing[:4]}"
            )

        # ── T2: Multiple new accounts in same batch ──────────────────────────
        reset_tables(spark, config)
        write_source_rows(spark, config["source_table"], [
            build_source_row(3001, "2026-01", ts, balance=1000, actual_payment=100),
            build_source_row(3002, "2026-01", ts, balance=2000, actual_payment=200),
            build_source_row(3003, "2026-01", ts, balance=3000, actual_payment=300),
        ])
        module.cleanup(spark)
        module.run_pipeline(spark, config)

        for acct, bal in [(3001, 1000), (3002, 2000), (3003, 3000)]:
            s = fetch_single_row(spark, config["destination_table"], acct, "2026-01")
            l = fetch_single_row(spark, config["latest_history_table"], acct, "2026-01")
            assert_equal(s["balance_am_history"][0], float(bal), f"T2 acct={acct} balance[0]")
            assert_history_lengths(s, l)
            assert_summary_prefix_of_latest(s, l)

        # ── T3: Grid column derived from rating history ───────────────────────
        reset_tables(spark, config)
        write_source_rows(spark, config["source_table"], [
            build_source_row(4001, "2026-01", ts, payment_rating="3"),
        ])
        module.cleanup(spark)
        module.run_pipeline(spark, config)

        s = fetch_single_row(spark, config["destination_table"], 4001, "2026-01")
        # Grid = concat_ws of rating history with placeholder '?' for nulls
        # Single row: first char should be "3", rest "?"
        grid = s.get("payment_history_grid") or ""
        assert_equal(grid[0], "3", "T3 grid col first char = rating value")
        assert_true(all(c == "?" for c in grid[1:]), f"T3 trailing grid chars must be ?: {grid[:8]}")

        # ── T4: latest_summary must match summary for new accounts ────────────
        assert_latest_matches_summary_v5(spark, config["destination_table"], config["latest_history_table"])

        print("[PASS] test_v5_case_i_new_accounts")
    finally:
        spark.stop()


if __name__ == "__main__":
    test_v5_case_i_new_accounts()
