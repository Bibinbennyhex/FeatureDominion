"""
test_v5_latest_summary_consistency.py
---------------------------------------
Asserts that after every pipeline run, latest_summary:
  1. Contains exactly one row per key (no duplicates)
  2. Row corresponds to the highest rpt_as_of_mo in summary for that key
  3. History arrays are 72 slots (not 36)
  4. Prefix (first 36 slots) matches the corresponding summary row exactly
  5. Tail (slots 36-71) is not destroyed by summary-level operations

Scenario matrix:
  T1: Case I   → latest created correctly
  T2: Case II  → latest advances to new max month
  T3: Case III (backfill older) → latest stays on max month, arrays patched
  T4: Case III (same-month update) → latest updated in-place
  T5: Soft-delete older month → latest unchanged, history nullified
  T6: Soft-delete latest month → latest falls back to prior row
  T7: Multi-account run → each account independently correct
"""
from datetime import datetime

from pyspark.sql import functions as F

from v5_contract_utils import (
    HISTORY_COLS,
    LATEST_HISTORY_LEN,
    SUMMARY_HISTORY_LEN,
    assert_equal,
    assert_history_lengths,
    assert_summary_prefix_of_latest,
    assert_true,
    assert_latest_matches_summary_v5,
    history,
    load_v5_module,
    pad_latest_rows,
)
from v5_test_utils import (
    create_spark_session,
    make_config,
    reset_tables,
    write_source_rows,
    write_summary_rows,
    fetch_single_row,
    fetch_rows,
    build_source_row,
    build_summary_row,
)


def _no_dupes_in_latest(spark, table: str, label: str) -> None:
    dup_count = (
        spark.table(table)
        .groupBy("cons_acct_key")
        .count()
        .filter(F.col("count") > 1)
        .count()
    )
    assert_true(dup_count == 0, f"{label}: latest_summary has duplicate keys ({dup_count})")


def test_v5_latest_summary_consistency() -> None:
    module = load_v5_module("_v5_latest_consistency")
    spark  = create_spark_session("v5_latest_summary_consistency")
    config = make_config("lat_cons")

    def _latest(acct: int, month: str):
        return fetch_single_row(spark, config["latest_history_table"], acct, month)

    def _summary(acct: int, month: str):
        return fetch_single_row(spark, config["destination_table"], acct, month)

    try:
        # ── T1: Case I latest creation ────────────────────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)
        module.preload_run_table_columns(spark, config)

        ts1 = datetime(2026, 1, 15)
        write_source_rows(spark, config["source_table"], [
            build_source_row(1101, "2026-01", ts1, balance=4000, actual_payment=400),
        ])
        module.run_pipeline(spark, config)

        l = _latest(1101, "2026-01")
        s = _summary(1101, "2026-01")
        _no_dupes_in_latest(spark, config["latest_history_table"], "T1")
        assert_history_lengths(s, l)
        assert_summary_prefix_of_latest(s, l)
        assert_equal(l["rpt_as_of_mo"], "2026-01", "T1 latest month")

        # ── T2: Case II advances latest to new month ──────────────────────────
        ts2 = datetime(2026, 2, 5)
        write_source_rows(spark, config["source_table"], [
            build_source_row(1101, "2026-02", ts2, balance=3900, actual_payment=390),
        ])
        module.run_pipeline(spark, config)

        l2 = _latest(1101, "2026-02")
        s2 = _summary(1101, "2026-02")
        _no_dupes_in_latest(spark, config["latest_history_table"], "T2")
        assert_equal(l2["rpt_as_of_mo"], "2026-02", "T2 latest advanced to Feb")
        assert_history_lengths(s2, l2)
        assert_summary_prefix_of_latest(s2, l2)

        # ── T3: Case III backfill older month → latest stays at Feb ───────────
        ts3 = datetime(2026, 3, 1)
        write_source_rows(spark, config["source_table"], [
            build_source_row(1101, "2026-01", ts3, balance=4200, actual_payment=420),
        ])
        module.run_pipeline(spark, config)

        l3 = _latest(1101, "2026-02")           # still at Feb
        s3 = _summary(1101, "2026-02")
        _no_dupes_in_latest(spark, config["latest_history_table"], "T3")
        assert_equal(l3["rpt_as_of_mo"], "2026-02", "T3 latest stays at Feb after backfill")
        # Feb's history[1] (= Jan) should be patched to backfilled value
        assert_equal(s3["balance_am_history"][1], 4200.0, "T3 Feb balance[1] patched in summary")
        assert_equal(l3["balance_am_history"][1], 4200.0, "T3 Feb balance[1] patched in latest")
        assert_history_lengths(s3, l3)
        assert_summary_prefix_of_latest(s3, l3)

        # ── T4: Case III same-month update → latest updated in-place ──────────
        ts4 = datetime(2026, 4, 1)
        write_source_rows(spark, config["source_table"], [
            build_source_row(1101, "2026-02", ts4, balance=3800, actual_payment=380),
        ])
        module.run_pipeline(spark, config)

        l4 = _latest(1101, "2026-02")
        s4 = _summary(1101, "2026-02")
        _no_dupes_in_latest(spark, config["latest_history_table"], "T4")
        assert_equal(l4["balance_am_history"][0], 3800.0, "T4 latest balance[0] updated")
        assert_history_lengths(s4, l4)
        assert_summary_prefix_of_latest(s4, l4)

        # ── T5: Soft-delete older month → latest unchanged ────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        seed_ts = datetime(2026, 1, 1)
        jan = build_summary_row(1102, "2026-01", seed_ts, balance=6000,
                                balance_history=history({0: 6000}, SUMMARY_HISTORY_LEN))
        feb = build_summary_row(1102, "2026-02", seed_ts, balance=5900,
                                balance_history=history({0: 5900, 1: 6000}, SUMMARY_HISTORY_LEN))
        write_summary_rows(spark, config["destination_table"], [jan, feb])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([feb]))
        module.preload_run_table_columns(spark, config)

        del_ts = datetime(2026, 3, 1)
        write_source_rows(spark, config["source_table"], [
            build_source_row(1102, "2026-01", del_ts, soft_del_cd="1"),
        ])
        module.run_pipeline(spark, config)

        l5 = _latest(1102, "2026-02")
        _no_dupes_in_latest(spark, config["latest_history_table"], "T5")
        assert_equal(l5["rpt_as_of_mo"], "2026-02", "T5 latest stays at Feb after older delete")
        # Feb[1] nullified in latest as well
        assert_true(l5["balance_am_history"][1] is None, "T5 latest Feb[1] nullified after Jan delete")

        # ── T6: Soft-delete latest month → latest falls back ──────────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        jan6 = build_summary_row(1103, "2026-01", seed_ts, balance=7000,
                                 balance_history=history({0: 7000}, SUMMARY_HISTORY_LEN))
        feb6 = build_summary_row(1103, "2026-02", seed_ts, balance=6900,
                                 balance_history=history({0: 6900, 1: 7000}, SUMMARY_HISTORY_LEN))
        write_summary_rows(spark, config["destination_table"], [jan6, feb6])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([feb6]))
        module.preload_run_table_columns(spark, config)

        del_ts6 = datetime(2026, 3, 15)
        write_source_rows(spark, config["source_table"], [
            build_source_row(1103, "2026-02", del_ts6, soft_del_cd="4"),
        ])
        module.run_pipeline(spark, config)

        _no_dupes_in_latest(spark, config["latest_history_table"], "T6")
        # latest_summary for 1103 should now be Jan
        all_latest = fetch_rows(spark, config["latest_history_table"], 1103)
        assert_equal(len(all_latest), 1, "T6 latest_summary one row per account")
        assert_equal(all_latest[0]["rpt_as_of_mo"], "2026-01", "T6 latest fell back to Jan")

        # ── T7: Multi-account run consistency ────────────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)
        module.preload_run_table_columns(spark, config)

        multi_ts = datetime(2026, 2, 1)
        write_source_rows(spark, config["source_table"], [
            build_source_row(1201, "2026-01", multi_ts, balance=1000),
            build_source_row(1202, "2026-01", multi_ts, balance=2000),
            build_source_row(1203, "2026-01", multi_ts, balance=3000),
        ])
        module.run_pipeline(spark, config)

        _no_dupes_in_latest(spark, config["latest_history_table"], "T7")
        for acct, bal in [(1201, 1000), (1202, 2000), (1203, 3000)]:
            l7 = _latest(acct, "2026-01")
            s7 = _summary(acct, "2026-01")
            assert_equal(l7["balance_am_history"][0], float(bal), f"T7 acct={acct} balance[0]")
            assert_history_lengths(s7, l7)
            assert_summary_prefix_of_latest(s7, l7)

        assert_latest_matches_summary_v5(
            spark, config["destination_table"], config["latest_history_table"]
        )

        print("[PASS] test_v5_latest_summary_consistency")
    finally:
        spark.stop()


if __name__ == "__main__":
    test_v5_latest_summary_consistency()
