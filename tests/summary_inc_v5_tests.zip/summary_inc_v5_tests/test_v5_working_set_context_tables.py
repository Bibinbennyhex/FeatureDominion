"""
test_v5_working_set_context_tables.py
---------------------------------------
Verifies that materialize_working_set_context_tables:
  T1: Creates WORKSET_LATEST_SUMMARY_TABLE containing only classified accounts
  T2: Creates WORKSET_SUMMARY_CASE3_TABLE containing ALL summary rows for Case III keys
      (not scoped to any month window – full history for correct array rebuild)
  T3: WORKSET_SUMMARY_CASE3_TABLE excludes accounts that are NOT Case III
  T4: Non-Case-III run → case3 context table is empty (or not created)
  T5: Pipeline uses the workset tables as context (not the live tables directly)
      by checking that removing the live table rows doesn't break the run
  T6: use_working_set_latest_context=False → falls back to live latest_summary table
"""
from datetime import datetime

from pyspark.sql import functions as F

from v5_contract_utils import (
    WORKSET_LATEST_SUMMARY_TABLE if hasattr(__import__("v5_contract_utils"), "WORKSET_LATEST_SUMMARY_TABLE")
    else None,
    assert_true,
    assert_equal,
    load_v5_module,
    pad_latest_rows,
)
from v5_test_utils import (
    create_spark_session,
    make_config,
    reset_tables,
    write_source_rows,
    write_summary_rows,
    fetch_single_row,
    build_source_row,
    build_summary_row,
)

# Pull workset constants from the v5 module directly
_module = load_v5_module("_v5_workset_const")
WORKSET_LATEST  = _module.WORKSET_LATEST_SUMMARY_TABLE
WORKSET_CASE3   = _module.WORKSET_SUMMARY_CASE3_TABLE


def test_v5_working_set_context_tables() -> None:
    module = load_v5_module("_v5_workset_ctx")
    spark  = create_spark_session("v5_working_set_context_tables")
    config = make_config("workset_ctx")
    config["use_working_set_latest_context"]       = True
    config["use_working_set_case3_summary_context"] = True

    try:
        # ── T1: workset_latest_summary contains only classified accounts ───────
        reset_tables(spark, config)
        module.cleanup(spark)

        seed_ts = datetime(2026, 1, 1)
        src_ts  = datetime(2026, 2, 1)

        # Two existing accounts in latest_summary; only one appears in source
        ex1 = build_summary_row(2001, "2026-01", seed_ts, balance=5000)
        ex2 = build_summary_row(2002, "2026-01", seed_ts, balance=6000)
        write_summary_rows(spark, config["destination_table"], [ex1, ex2])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([ex1, ex2]))
        module.preload_run_table_columns(spark, config)

        write_source_rows(spark, config["source_table"], [
            build_source_row(2001, "2026-02", src_ts, balance=4900),  # Case II for 2001 only
        ])
        classified = module.load_and_classify_accounts(spark, config)
        module.materialize_working_set_context_tables(spark, classified, config)

        ws_latest = spark.read.table(WORKSET_LATEST)
        keys_in_workset = {int(r["cons_acct_key"]) for r in ws_latest.select("cons_acct_key").collect()}
        assert_true(2001 in keys_in_workset, "T1 classified account 2001 in workset_latest")
        assert_true(2002 not in keys_in_workset, "T1 non-classified account 2002 NOT in workset_latest")

        # ── T2: workset_summary_case3 contains ALL summary rows for Case III key
        reset_tables(spark, config)
        module.cleanup(spark)

        case3_acct = 2003
        # Seed several historical months for the Case III account
        months_2003 = [
            build_summary_row(case3_acct, "2020-01", seed_ts, balance=3000),
            build_summary_row(case3_acct, "2023-06", seed_ts, balance=3500),
            build_summary_row(case3_acct, "2026-01", seed_ts, balance=4000),
        ]
        anchor = build_summary_row(9999, "2026-12", seed_ts, balance=100)

        write_summary_rows(spark, config["destination_table"], months_2003 + [anchor])
        write_summary_rows(spark, config["latest_history_table"],
                           pad_latest_rows([months_2003[-1], anchor]))
        module.preload_run_table_columns(spark, config)

        # Backfill triggers Case III
        write_source_rows(spark, config["source_table"], [
            build_source_row(case3_acct, "2025-12", src_ts, balance=3900),
        ])
        classified2 = module.load_and_classify_accounts(spark, config)
        module.materialize_working_set_context_tables(spark, classified2, config)

        ws_case3 = spark.read.table(WORKSET_CASE3)
        case3_months_in_ws = {
            r["rpt_as_of_mo"]
            for r in ws_case3.filter(F.col("cons_acct_key") == case3_acct)
                             .select("rpt_as_of_mo").collect()
        }
        expected_months = {"2020-01", "2023-06", "2026-01"}
        assert_equal(case3_months_in_ws, expected_months,
                     "T2 workset_summary_case3 contains ALL months for case3 account")

        # Anchor (non-case3) should NOT be in the case3 workset
        anchor_in_ws = ws_case3.filter(F.col("cons_acct_key") == 9999).count()
        assert_equal(anchor_in_ws, 0, "T3 non-case3 account not in workset_summary_case3")

        # ── T4: No Case III in batch → case3 context is empty ─────────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        only_new = build_summary_row(9999, "2020-01", seed_ts, balance=100)
        write_summary_rows(spark, config["destination_table"], [only_new])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([only_new]))
        module.preload_run_table_columns(spark, config)

        write_source_rows(spark, config["source_table"], [
            build_source_row(2004, "2026-01", src_ts, balance=1000),   # pure Case I
        ])
        classified3 = module.load_and_classify_accounts(spark, config)
        module.materialize_working_set_context_tables(spark, classified3, config)

        ws3 = spark.read.table(WORKSET_CASE3)
        assert_equal(ws3.count(), 0, "T4 workset_summary_case3 empty when no Case III rows")

        # ── T5: Flag-off → falls back to live table ────────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        config_no_ws = dict(config)
        config_no_ws["use_working_set_latest_context"]        = False
        config_no_ws["use_working_set_case3_summary_context"] = False

        live_row = build_summary_row(2005, "2026-01", seed_ts, balance=8000)
        write_summary_rows(spark, config_no_ws["destination_table"], [live_row])
        write_summary_rows(spark, config_no_ws["latest_history_table"], pad_latest_rows([live_row]))
        module.preload_run_table_columns(spark, config_no_ws)

        write_source_rows(spark, config_no_ws["source_table"], [
            build_source_row(2005, "2026-02", src_ts, balance=7900),
        ])
        # Should complete without error even without workset
        module.run_pipeline(spark, config_no_ws)

        s5 = fetch_single_row(spark, config_no_ws["destination_table"], 2005, "2026-02")
        assert_equal(s5["balance_am_history"][0], 7900.0,
                     "T5 pipeline works correctly without working-set tables")

        print("[PASS] test_v5_working_set_context_tables")
    finally:
        spark.stop()


if __name__ == "__main__":
    test_v5_working_set_context_tables()
