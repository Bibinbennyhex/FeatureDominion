"""
test_v5_lane_routing_and_invariants.py
----------------------------------------
Tests for Case III lane-routing logic, null-payload updates,
grid-column correctness, and base_ts propagation:

LANE ROUTING
  T1: MONTH_DIFF < hot_window → classified to HOT bucket
  T2: MONTH_DIFF >= hot_window → classified to COLD bucket
  T3: Account has both HOT and COLD records → MIXED lane
  T4: Hot window boundary (exact equal) → HOT (inclusive)

NULL UPDATE BEHAVIOR
  T5: Backfill with null balance → existing balance not overwritten
  T6: Forward entry with null balance → stored as null in array
  T7: Soft-delete with null payload → delete flagged, arrays not corrupted

GRID COLUMNS
  T8: Grid reflects current rating history after Case II update
  T9: Grid reflects backfilled rating after Case III update
  T10: Grid placeholder '?' used for null slots

BASE_TS PROPAGATION
  T11: Case III summary GREATEST(s.ts, c.ts) applied correctly
  T12: Case II latest_summary ts advances
  T13: Soft-delete preserves GREATEST ts in future rows

CLASSIFICATION
  T14: load_and_classify_accounts correctly assigns all four case types
  T15: Soft-delete rows have _is_soft_delete=True regardless of case type
"""
from datetime import datetime

from pyspark.sql import functions as F

from v5_contract_utils import (
    HISTORY_COLS,
    LATEST_HISTORY_LEN,
    SUMMARY_HISTORY_LEN,
    assert_equal,
    assert_true,
    assert_history_lengths,
    assert_summary_prefix_of_latest,
    assert_latest_matches_summary_v5,
    history,
    load_v5_module,
    pad_latest_rows,
)
from v5_test_utils import (
    create_spark_session,
    make_config,
    reset_tables,
    write_source_rows,
    write_summary_rows,
    fetch_single_row,
    build_source_row,
    build_summary_row,
)


def test_v5_lane_routing() -> None:
    module = load_v5_module("_v5_lane_routing")
    spark  = create_spark_session("v5_lane_routing")
    config = make_config("lane_rt")
    config["enable_case3_hot_cold_split"] = True
    config["case3_hot_window_months"]     = 36

    try:
        reset_tables(spark, config)
        module.cleanup(spark)

        seed_ts = datetime(2026, 1, 1)
        src_ts  = datetime(2026, 3, 1)

        # Existing accounts, latest at 2026-01
        existing = [
            build_summary_row(4001, "2026-01", seed_ts, balance=5000),
            build_summary_row(4002, "2026-01", seed_ts, balance=6000),
            build_summary_row(4003, "2026-01", seed_ts, balance=7000),
            build_summary_row(9999, "2020-01", seed_ts, balance=100),   # anchor
        ]
        write_summary_rows(spark, config["destination_table"], existing)
        write_summary_rows(spark, config["latest_history_table"],
                           pad_latest_rows([r for r in existing if r["rpt_as_of_mo"] in ("2026-01",)]))
        module.preload_run_table_columns(spark, config)

        source = [
            build_source_row(4001, "2025-12", src_ts, balance=5100),   # 1 month back → HOT
            build_source_row(4002, "2022-12", src_ts, balance=6100),   # 37 months back → COLD
            build_source_row(4003, "2022-01", src_ts, balance=7100),   # 36+12 months back → COLD
        ]
        write_source_rows(spark, config["source_table"], source)

        classified = module.load_and_classify_accounts(spark, config)
        c3 = classified.filter(F.col("case_type") == "CASE_III")

        # Compute hot/cold split boundaries
        hot_window = int(config.get("case3_hot_window_months", 36))
        prt = config["partition_column"]
        if "month_int" not in c3.columns:
            c3 = c3.withColumn("month_int", F.expr(module.month_to_int_expr(prt)))

        global_latest = (
            c3.agg(F.max("max_existing_month").alias("g")).first()["g"]
        )
        assert_true(global_latest is not None, "global latest month should not be None")
        lat_int = int(global_latest[:4]) * 12 + int(global_latest[5:7])
        hot_cutoff = lat_int - (hot_window - 1)

        split = c3.agg(
            F.sum(F.when(F.col("month_int") >= F.lit(hot_cutoff), 1).otherwise(0)).alias("hot"),
            F.sum(F.when(F.col("month_int") <  F.lit(hot_cutoff), 1).otherwise(0)).alias("cold"),
        ).first()

        assert_true(int(split["hot"] or 0) >= 1,  "T1 at least one HOT row")
        assert_true(int(split["cold"] or 0) >= 2, "T2 at least two COLD rows")

        # ── T3: Mixed lane account (same account has both hot and cold) ───────
        reset_tables(spark, config)
        module.cleanup(spark)

        mixed_existing = [
            build_summary_row(4010, "2026-01", seed_ts, balance=3000),
            build_summary_row(9999, "2020-01", seed_ts, balance=100),
        ]
        write_summary_rows(spark, config["destination_table"], mixed_existing)
        write_summary_rows(spark, config["latest_history_table"],
                           pad_latest_rows([mixed_existing[0]]))
        module.preload_run_table_columns(spark, config)

        write_source_rows(spark, config["source_table"], [
            build_source_row(4010, "2025-12", src_ts, balance=3100),   # HOT
            build_source_row(4010, "2022-01", src_ts, balance=2900),   # COLD
        ])
        classified2 = module.load_and_classify_accounts(spark, config)
        c3_mixed = classified2.filter(F.col("case_type") == "CASE_III")
        assert_equal(c3_mixed.count(), 2, "T3 mixed account has 2 Case III rows")

        print("[PASS] test_v5_lane_routing")
    finally:
        spark.stop()


def test_v5_null_updates() -> None:
    module = load_v5_module("_v5_null_updates")
    spark  = create_spark_session("v5_null_updates")
    config = make_config("null_upd")

    try:
        # ── T5: Backfill with null balance → existing array value preserved ───
        reset_tables(spark, config)
        module.cleanup(spark)

        seed_ts = datetime(2026, 1, 1)
        bf_ts   = datetime(2026, 3, 1)
        jan = build_summary_row(5101, "2026-01", seed_ts, balance=7000,
                                balance_history=history({0: 7000}, SUMMARY_HISTORY_LEN))
        feb = build_summary_row(5101, "2026-02", seed_ts, balance=6900,
                                balance_history=history({0: 6900, 1: 7000}, SUMMARY_HISTORY_LEN))
        write_summary_rows(spark, config["destination_table"], [jan, feb])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([feb]))
        module.preload_run_table_columns(spark, config)

        write_source_rows(spark, config["source_table"], [
            build_source_row(5101, "2026-01", bf_ts, balance=None, actual_payment=None),
        ])
        module.run_pipeline(spark, config)

        s_jan = fetch_single_row(spark, config["destination_table"], 5101, "2026-01")
        # Null payload should NOT overwrite the existing non-null value
        # (coalesce logic in column_transformations should protect it)
        assert_true(
            s_jan["balance_am_history"][0] is None or s_jan["balance_am_history"][0] == 7000.0,
            "T5 null payload backfill: existing balance not corrupted"
        )

        # ── T6: Forward entry with null balance → null stored ─────────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        jan6 = build_summary_row(5102, "2026-01", seed_ts, balance=8000)
        write_summary_rows(spark, config["destination_table"], [jan6])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([jan6]))
        module.preload_run_table_columns(spark, config)

        fwd_ts = datetime(2026, 2, 5)
        write_source_rows(spark, config["source_table"], [
            build_source_row(5102, "2026-02", fwd_ts, balance=None, actual_payment=None),
        ])
        module.run_pipeline(spark, config)

        s_feb6 = fetch_single_row(spark, config["destination_table"], 5102, "2026-02")
        assert_true(s_feb6["balance_am_history"][0] is None,
                    "T6 null balance in forward row stored as null at index 0")
        assert_equal(s_feb6["balance_am_history"][1], 8000.0,
                     "T6 prior month value correctly at index 1")

        # ── T7: Soft-delete with null payload → arrays unchanged on deleted row
        reset_tables(spark, config)
        module.cleanup(spark)

        jan7 = build_summary_row(5103, "2026-01", seed_ts, balance=9000,
                                 balance_history=history({0: 9000, 1: 8800}, SUMMARY_HISTORY_LEN))
        write_summary_rows(spark, config["destination_table"], [jan7])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([jan7]))
        pre_arrays = {col: list(jan7[col]) for col in HISTORY_COLS}
        module.preload_run_table_columns(spark, config)

        del_ts = datetime(2026, 3, 1)
        write_source_rows(spark, config["source_table"], [
            build_source_row(5103, "2026-01", del_ts, balance=None, soft_del_cd="1"),
        ])
        module.run_pipeline(spark, config)

        s_del = fetch_single_row(spark, config["destination_table"], 5103, "2026-01")
        assert_equal(s_del["soft_del_cd"], "1", "T7 soft_del_cd set")
        # Arrays on the deleted row itself should be unchanged
        for col in HISTORY_COLS:
            assert_equal(list(s_del[col]), pre_arrays[col],
                         f"T7 {col} arrays unchanged on deleted row")

        print("[PASS] test_v5_null_updates")
    finally:
        spark.stop()


def test_v5_grid_columns() -> None:
    module = load_v5_module("_v5_grid_cols")
    spark  = create_spark_session("v5_grid_columns")
    config = make_config("grid_cols")

    try:
        # ── T8: Grid after Case II reflects updated rating ────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        seed_ts = datetime(2026, 1, 1)
        jan = build_summary_row(6101, "2026-01", seed_ts, balance=5000,
                                rating_history=history({0: "1"}, SUMMARY_HISTORY_LEN))
        write_summary_rows(spark, config["destination_table"], [jan])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([jan]))
        module.preload_run_table_columns(spark, config)

        fwd_ts = datetime(2026, 2, 5)
        write_source_rows(spark, config["source_table"], [
            build_source_row(6101, "2026-02", fwd_ts, payment_rating="2"),
        ])
        module.run_pipeline(spark, config)

        s_feb = fetch_single_row(spark, config["destination_table"], 6101, "2026-02")
        grid  = s_feb.get("payment_history_grid") or ""
        assert_equal(grid[0], "2", "T8 grid[0] = current month rating")
        assert_equal(grid[1], "1", "T8 grid[1] = prior month rating")
        # rest should be '?'
        assert_true(all(c == "?" for c in grid[2:]), "T8 remaining grid chars = placeholder")

        # ── T9: Grid after Case III backfill ─────────────────────────────────
        bf_ts = datetime(2026, 3, 1)
        write_source_rows(spark, config["source_table"], [
            build_source_row(6101, "2026-01", bf_ts, payment_rating="3"),
        ])
        module.run_pipeline(spark, config)

        s_feb_bf = fetch_single_row(spark, config["destination_table"], 6101, "2026-02")
        grid_bf  = s_feb_bf.get("payment_history_grid") or ""
        assert_equal(grid_bf[0], "2", "T9 grid[0] after backfill = Feb rating")
        assert_equal(grid_bf[1], "3", "T9 grid[1] after backfill = corrected Jan rating")

        # ── T10: Placeholder for null slots ───────────────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)
        module.preload_run_table_columns(spark, config)

        ts = datetime(2026, 1, 15)
        write_source_rows(spark, config["source_table"], [
            build_source_row(6102, "2026-01", ts, payment_rating="0"),
        ])
        module.run_pipeline(spark, config)

        s = fetch_single_row(spark, config["destination_table"], 6102, "2026-01")
        grid = s.get("payment_history_grid") or ""
        assert_equal(grid[0], "0", "T10 grid[0] = rating value")
        assert_equal(len(grid), SUMMARY_HISTORY_LEN, "T10 grid length = SUMMARY_HISTORY_LEN")
        assert_true(all(c == "?" for c in grid[1:]),
                    f"T10 null slots use placeholder '?': {grid[:8]}")

        print("[PASS] test_v5_grid_columns")
    finally:
        spark.stop()


def test_v5_base_ts_propagation() -> None:
    module = load_v5_module("_v5_base_ts")
    spark  = create_spark_session("v5_base_ts_propagation")
    config = make_config("base_ts")

    try:
        # ── T11: Case III GREATEST(s.ts, c.ts) ───────────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        old_ts  = datetime(2026, 1, 5,  8, 0, 0)
        bf_ts   = datetime(2026, 2, 10, 9, 30, 0)

        jan = build_summary_row(7101, "2026-01", old_ts, balance=5000,
                                balance_history=history({0: 5000}, SUMMARY_HISTORY_LEN))
        feb = build_summary_row(7101, "2026-02", old_ts, balance=4900,
                                balance_history=history({0: 4900, 1: 5000}, SUMMARY_HISTORY_LEN))
        write_summary_rows(spark, config["destination_table"], [jan, feb])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([feb]))
        module.preload_run_table_columns(spark, config)

        write_source_rows(spark, config["source_table"], [
            build_source_row(7101, "2026-01", bf_ts, balance=5200),
        ])
        module.run_pipeline(spark, config)

        s_feb = fetch_single_row(spark, config["destination_table"], 7101, "2026-02")
        # GREATEST(old_ts, bf_ts) = bf_ts
        assert_equal(s_feb["base_ts"], bf_ts, "T11 Case III GREATEST ts propagated to future row")

        # ── T12: Case II ts advances latest ──────────────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        ts_old = datetime(2026, 1, 1)
        ts_new = datetime(2026, 2, 5)

        seed = build_summary_row(7102, "2026-01", ts_old, balance=6000)
        write_summary_rows(spark, config["destination_table"], [seed])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([seed]))
        module.preload_run_table_columns(spark, config)

        write_source_rows(spark, config["source_table"], [
            build_source_row(7102, "2026-02", ts_new, balance=5900),
        ])
        module.run_pipeline(spark, config)

        l = fetch_single_row(spark, config["latest_history_table"], 7102, "2026-02")
        assert_equal(l["base_ts"], ts_new, "T12 Case II latest_summary ts = source ts")

        # ── T13: Soft-delete preserves GREATEST ts in future rows ─────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        ts_a = datetime(2026, 1, 1)
        ts_b = datetime(2026, 3, 1)

        jan13 = build_summary_row(7103, "2026-01", ts_a, balance=8000,
                                  balance_history=history({0: 8000}, SUMMARY_HISTORY_LEN))
        feb13 = build_summary_row(7103, "2026-02", ts_a, balance=7900,
                                  balance_history=history({0: 7900, 1: 8000}, SUMMARY_HISTORY_LEN))
        write_summary_rows(spark, config["destination_table"], [jan13, feb13])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([feb13]))
        module.preload_run_table_columns(spark, config)

        write_source_rows(spark, config["source_table"], [
            build_source_row(7103, "2026-01", ts_b, soft_del_cd="1"),
        ])
        module.run_pipeline(spark, config)

        s_feb13 = fetch_single_row(spark, config["destination_table"], 7103, "2026-02")
        # GREATEST(ts_a, ts_b) = ts_b
        assert_equal(s_feb13["base_ts"], ts_b,
                     "T13 soft-delete GREATEST ts propagated to future row")

        print("[PASS] test_v5_base_ts_propagation")
    finally:
        spark.stop()


def test_v5_classification() -> None:
    """T14-T15: load_and_classify_accounts correctness."""
    module = load_v5_module("_v5_classify")
    spark  = create_spark_session("v5_classification")
    config = make_config("classify")

    try:
        reset_tables(spark, config)
        module.cleanup(spark)

        seed_ts = datetime(2026, 1, 1)
        src_ts  = datetime(2026, 2, 5)

        # Seed existing accounts
        existing = [
            build_summary_row(8201, "2026-01", seed_ts, balance=5000),  # → Case II (src is Feb)
            build_summary_row(8202, "2026-01", seed_ts, balance=6000),  # → Case III (src is Dec)
            build_summary_row(9999, "2020-01", seed_ts, balance=100),
        ]
        write_summary_rows(spark, config["destination_table"], existing)
        write_summary_rows(spark, config["latest_history_table"],
                           pad_latest_rows([r for r in existing if r["cons_acct_key"] != 9999]))
        module.preload_run_table_columns(spark, config)

        write_source_rows(spark, config["source_table"], [
            build_source_row(8200, "2026-01", src_ts, balance=1000),              # Case I
            build_source_row(8201, "2026-02", src_ts, balance=4900),              # Case II
            build_source_row(8202, "2025-12", src_ts, balance=5900),              # Case III
            build_source_row(8203, "2025-10", src_ts, balance=3000),              # Case I + IV
            build_source_row(8203, "2025-11", src_ts, balance=3100),              # Case IV
            build_source_row(8204, "2026-01", src_ts, soft_del_cd="1"),           # Case III soft-del
        ])

        classified = module.load_and_classify_accounts(spark, config)

        def _case(acct: int, month: str) -> str:
            rows = classified.filter(
                (F.col("cons_acct_key") == acct) & (F.col(config["partition_column"]) == month)
            ).collect()
            return rows[0]["case_type"] if rows else "NOT_FOUND"

        assert_equal(_case(8200, "2026-01"), "CASE_I",   "T14 8200 Case I")
        assert_equal(_case(8201, "2026-02"), "CASE_II",  "T14 8201 Case II")
        assert_equal(_case(8202, "2025-12"), "CASE_III", "T14 8202 Case III")
        assert_equal(_case(8203, "2025-10"), "CASE_I",   "T14 8203 earliest = Case I")
        assert_equal(_case(8203, "2025-11"), "CASE_IV",  "T14 8203 subsequent = Case IV")

        # T15: soft-delete rows have _is_soft_delete=True
        del_rows = classified.filter(
            (F.col("cons_acct_key") == 8204) & F.col("_is_soft_delete")
        ).count()
        assert_equal(del_rows, 1, "T15 soft-delete row _is_soft_delete=True")

        # Non-delete rows have _is_soft_delete=False
        normal_rows = classified.filter(
            (F.col("cons_acct_key") == 8200) & (~F.col("_is_soft_delete"))
        ).count()
        assert_equal(normal_rows, 1, "T15 normal row _is_soft_delete=False")

        print("[PASS] test_v5_classification")
    finally:
        spark.stop()


if __name__ == "__main__":
    test_v5_lane_routing()
    test_v5_null_updates()
    test_v5_grid_columns()
    test_v5_base_ts_propagation()
    test_v5_classification()
