"""
test_v5_watermark_tracker.py
------------------------------
Tests for the run-tracking / watermark system:
  T1: Tracker table created on first run
  T2: Successful run → status=SUCCESS, snapshot_ids updated
  T3: Status transitions: RUNNING during run, SUCCESS after
  T4: Committed watermark row reflects minimum of summary/latest max months
  T5: previous_successful_snapshot_id preserved across runs
  T6: validate_config → rejects configs missing required fields
  T7: Helper functions: _to_int, _safe_min, month_to_int_expr, _int_to_partition
  T8: build_month_chunks returns balanced bins
"""
from datetime import datetime
from typing import Any, Dict

from pyspark.sql import functions as F

from v5_contract_utils import (
    assert_equal,
    assert_true,
    load_v5_module,
    pad_latest_rows,
)
from v5_test_utils import (
    create_spark_session,
    make_config,
    reset_tables,
    write_source_rows,
    write_summary_rows,
    build_source_row,
    build_summary_row,
)


def _get_tracker_row(spark, tracker_table: str, source_name: str) -> Dict[str, Any]:
    rows = (
        spark.table(tracker_table)
        .filter(F.col("source_name") == source_name)
        .collect()
    )
    assert len(rows) == 1, f"Expected 1 tracker row for source_name={source_name}, got {len(rows)}"
    return rows[0].asDict()


def test_v5_watermark_tracker() -> None:
    module = load_v5_module("_v5_tracker")
    spark  = create_spark_session("v5_watermark_tracker")
    config = make_config("tracker_test")

    try:
        # ── T1: Tracker created on first run ─────────────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)
        module.preload_run_table_columns(spark, config)

        ts = datetime(2026, 2, 1)
        write_source_rows(spark, config["source_table"], [
            build_source_row(3001, "2026-01", ts, balance=5000),
        ])
        module.run_pipeline(spark, config)

        tracker_table = config["watermark_tracker_table"]
        assert_true(
            spark.catalog.tableExists(tracker_table),
            "T1 tracker table created after first run"
        )

        # ── T2: Successful run → status=SUCCESS ───────────────────────────────
        summary_row = _get_tracker_row(spark, tracker_table, "summary")
        assert_equal(summary_row["status"], "SUCCESS", "T2 summary tracker status")

        latest_row = _get_tracker_row(spark, tracker_table, "latest_summary")
        assert_equal(latest_row["status"], "SUCCESS", "T2 latest_summary tracker status")

        # ── T3: snapshot_id is non-None after run ─────────────────────────────
        assert_true(summary_row["current_snapshot_id"] is not None,
                    "T3 summary current_snapshot_id populated")
        assert_true(latest_row["current_snapshot_id"] is not None,
                    "T3 latest_summary current_snapshot_id populated")

        # ── T4: Committed watermark row exists ───────────────────────────────
        committed_row = _get_tracker_row(spark, tracker_table, "committed_ingestion_watermark")
        assert_equal(committed_row["status"], "SUCCESS", "T4 committed row status")
        assert_true(committed_row["max_rpt_as_of_mo"] is not None,
                    "T4 committed watermark max_rpt_as_of_mo set")

        # ── T5: previous_successful_snapshot_id advances across runs ──────────
        prev_snap_id = summary_row["current_snapshot_id"]

        write_source_rows(spark, config["source_table"], [
            build_source_row(3001, "2026-02", ts, balance=4900),
        ])
        module.run_pipeline(spark, config)

        summary_row2 = _get_tracker_row(spark, tracker_table, "summary")
        assert_equal(summary_row2["status"], "SUCCESS", "T5 second run status")
        assert_equal(summary_row2["previous_successful_snapshot_id"], prev_snap_id,
                     "T5 previous_successful_snapshot_id = prior current_snapshot_id")
        assert_true(
            summary_row2["current_snapshot_id"] != prev_snap_id,
            "T5 current_snapshot_id advanced after second write"
        )

        print("[PASS] test_v5_watermark_tracker (tracker lifecycle)")
    finally:
        spark.stop()


def test_v5_validate_config() -> None:
    """validate_config returns False for incomplete configs."""
    module = load_v5_module("_v5_validate_cfg")
    spark  = create_spark_session("v5_validate_config")

    try:
        good_config = make_config("validate_good")
        assert_true(module.validate_config(good_config), "Good config should pass validation")

        required_fields = [
            "source_table", "destination_table", "latest_history_table",
            "primary_column", "partition_column", "max_identifier_column",
        ]
        for field in required_fields:
            bad = dict(good_config)
            del bad[field]
            result = module.validate_config(bad)
            assert_true(not result, f"Config missing '{field}' should fail validation")

        print("[PASS] test_v5_validate_config")
    finally:
        spark.stop()


def test_v5_helper_functions() -> None:
    """Unit tests for pure helper functions that don't need Spark."""
    module = load_v5_module("_v5_helpers")

    # _to_int
    assert_equal(module._to_int("42", 0),   42,  "_to_int string")
    assert_equal(module._to_int(99, 0),     99,  "_to_int int passthrough")
    assert_equal(module._to_int("bad", 7),  7,   "_to_int bad string falls back")
    assert_equal(module._to_int(None, 5),   5,   "_to_int None falls back")

    # _safe_min
    assert_equal(module._safe_min(None, "2026-01"), "2026-01", "_safe_min left None")
    assert_equal(module._safe_min("2026-01", None), "2026-01", "_safe_min right None")
    assert_equal(module._safe_min("2025-12", "2026-01"), "2025-12", "_safe_min smaller wins")
    assert_equal(module._safe_min(None, None), None, "_safe_min both None")

    # _int_to_partition round-trip
    for month_str in ["2020-01", "2022-06", "2025-12", "2026-03"]:
        y, m = month_str.split("-")
        int_val = int(y) * 12 + int(m)
        back = module._int_to_partition(int_val)
        assert_equal(back, month_str, f"_int_to_partition round-trip for {month_str}")

    # month_to_int_expr is a SQL string expression — just check it's non-empty and references column
    expr = module.month_to_int_expr("rpt_as_of_mo")
    assert_true("rpt_as_of_mo" in expr, "month_to_int_expr references column name")
    assert_true("CAST" in expr.upper(), "month_to_int_expr uses CAST")

    print("[PASS] test_v5_helper_functions")


def test_v5_build_month_chunks() -> None:
    """Unit test for build_month_chunks greedy bin-packer."""
    from pyspark.sql import SparkSession
    module = load_v5_module("_v5_month_chunks")
    spark  = SparkSession.builder.master("local[1]").appName("v5_chunks_test") \
                         .config("spark.sql.shuffle.partitions", "2").getOrCreate()

    try:
        from pyspark.sql.types import StructType, StructField, StringType, LongType
        schema = StructType([
            StructField("rpt_as_of_mo", StringType()),
            StructField("count",        LongType()),
        ])
        data = [
            ("2026-01", 1000000),
            ("2026-02", 1000000),
            ("2026-03",  500000),
            ("2026-04",  200000),
        ]
        df = spark.createDataFrame(data, schema=schema)

        chunks = module.build_month_chunks(df, "rpt_as_of_mo")

        # All months must appear exactly once across all chunks
        all_months = [m for chunk in chunks for m in chunk]
        assert_equal(sorted(all_months), ["2026-01", "2026-02", "2026-03", "2026-04"],
                     "build_month_chunks covers all months exactly once")

        # At least two chunks expected (2026-01 alone fills target)
        assert_true(len(chunks) >= 1, "build_month_chunks produces at least one bin")

        # Empty dataframe → empty chunks
        empty_df = spark.createDataFrame([], schema=schema)
        empty_chunks = module.build_month_chunks(empty_df, "rpt_as_of_mo")
        assert_equal(empty_chunks, [], "build_month_chunks empty df returns []")

        print("[PASS] test_v5_build_month_chunks")
    finally:
        spark.stop()


if __name__ == "__main__":
    test_v5_validate_config()
    test_v5_helper_functions()
    test_v5_build_month_chunks()
    test_v5_watermark_tracker()
