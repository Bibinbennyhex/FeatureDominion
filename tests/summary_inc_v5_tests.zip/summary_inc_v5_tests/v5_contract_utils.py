"""
v5_contract_utils.py
--------------------
Shared test infrastructure for summary_inc_v5 tests.

Key differences from v4 contract:
  - Module path  : summary_inc_v5.py  (single file, no sub-version)
  - HISTORY_LENGTH constant : 36  (summary arrays)
  - latest_summary arrays  : 72 months  (LATEST_HISTORY_MIN_LEN_V4 = 72)
  - Case III lanes  : process_case_iii_hot / _cold / _mixed
    (no legacy single process_case_iii entry point)
  - Soft-delete codes: "1", "4"
  - Working-set tables now written with write_case_table_bucketed (Iceberg)
  - Rollback via Iceberg system.rollback_to_snapshot
"""
from __future__ import annotations

import importlib.util
import os
import sys
import types
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from pyspark.sql import Window
from pyspark.sql import functions as F


# ── Public constants ──────────────────────────────────────────────────────────
SUMMARY_HISTORY_LEN = 36
LATEST_HISTORY_LEN  = 72

HISTORY_COLS = [
    "actual_payment_am_history",
    "balance_am_history",
    "credit_limit_am_history",
    "past_due_am_history",
    "payment_rating_cd_history",
    "days_past_due_history",
    "asset_class_cd_4in_history",
]

DELETE_CODES = ("1", "4")

# v5 module cache key (avoids re-loading on repeated imports within one process)
_MODULE_CACHE_KEY = "_summary_inc_v5_loaded"


# ── Dependency stubs (boto3, dateutil) ────────────────────────────────────────
def ensure_dependency_stubs() -> None:
    """Inject lightweight stubs for optional runtime deps not available in test env."""
    try:
        import boto3  # noqa: F401
    except ImportError:
        stub = types.ModuleType("boto3")
        def _no_client(*a, **kw):
            raise RuntimeError("boto3.client must not be called in v5 tests")
        stub.client = _no_client  # type: ignore[attr-defined]
        sys.modules["boto3"] = stub

    try:
        from dateutil.relativedelta import relativedelta  # noqa: F401
    except ImportError:
        du_mod = types.ModuleType("dateutil")
        rel_mod = types.ModuleType("dateutil.relativedelta")
        class relativedelta:  # type: ignore[no-redef]
            def __init__(self, months: int = 0):
                self.months = months
        rel_mod.relativedelta = relativedelta  # type: ignore[attr-defined]
        du_mod.relativedelta = rel_mod  # type: ignore[attr-defined]
        sys.modules["dateutil"] = du_mod
        sys.modules["dateutil.relativedelta"] = rel_mod


# ── Module loader ─────────────────────────────────────────────────────────────
def resolve_v5_path(override: Optional[str] = None) -> Path:
    """
    Locate summary_inc_v5.py.

    Resolution order:
      1. ``override`` argument
      2. ``V5_PIPELINE_SCRIPT`` env var
      3. File co-located with this utils module
      4. Repo-relative paths (two common layouts)
    """
    raw = override or os.environ.get("V5_PIPELINE_SCRIPT", "")
    if raw:
        p = Path(raw)
        if p.is_absolute() and p.exists():
            return p
        # relative to cwd or repo root
        for base in (Path.cwd(), Path(__file__).resolve().parents[3]):
            candidate = base / p
            if candidate.exists():
                return candidate

    # Co-located
    here = Path(__file__).resolve().parent
    co = here / "summary_inc_v5.py"
    if co.exists():
        return co

    # Common repo layouts
    root = Path(__file__).resolve().parents[3]
    for candidate in [
        root / "main" / "summary_version_5" / "summary_inc_v5.py",
        root / "summary_inc_v5.py",
        here.parent / "summary_inc_v5.py",
    ]:
        if candidate.exists():
            return candidate

    raise FileNotFoundError(
        "Cannot locate summary_inc_v5.py. "
        "Set V5_PIPELINE_SCRIPT env var or place the file next to v5_contract_utils.py."
    )


def load_v5_module(cache_key: str = _MODULE_CACHE_KEY) -> Any:
    """Load (or return cached) summary_inc_v5 module."""
    ensure_dependency_stubs()
    cached = sys.modules.get(cache_key)
    if cached is not None:
        return cached
    path = resolve_v5_path()
    spec = importlib.util.spec_from_file_location(cache_key, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load module from {path}")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[cache_key] = mod
    # Register all aliases tests may import under
    for alias in ("summary_inc", "summary_inc_v5"):
        sys.modules[alias] = mod
    spec.loader.exec_module(mod)  # type: ignore[union-attr]
    return mod


# ── Array helpers ─────────────────────────────────────────────────────────────
def pad_history_array(values: Optional[Iterable[Any]], length: int = LATEST_HISTORY_LEN) -> List[Any]:
    arr = list(values or [])
    if len(arr) >= length:
        return arr[:length]
    return arr + [None] * (length - len(arr))


def history(slot_map: Dict[int, Any], length: int = SUMMARY_HISTORY_LEN) -> List[Any]:
    """Build a history array of *length* with explicit slot values; rest None."""
    arr: List[Any] = [None] * length
    for idx, val in slot_map.items():
        if 0 <= idx < length:
            arr[idx] = val
    return arr


def pad_latest_rows(rows: List[Dict[str, Any]], latest_len: int = LATEST_HISTORY_LEN) -> List[Dict[str, Any]]:
    """Return copies of rows with all history cols padded to latest_len."""
    out = []
    for row in rows:
        r = dict(row)
        for col in HISTORY_COLS:
            if col in r:
                r[col] = pad_history_array(r[col], latest_len)
        out.append(r)
    return out


# ── Assertion helpers ─────────────────────────────────────────────────────────
def assert_true(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def assert_equal(actual: Any, expected: Any, label: str) -> None:
    if actual != expected:
        raise AssertionError(f"{label}: expected={expected!r}, got={actual!r}")


def assert_history_lengths(
    summary_row: Dict[str, Any],
    latest_row: Dict[str, Any],
    summary_len: int = SUMMARY_HISTORY_LEN,
    latest_len: int = LATEST_HISTORY_LEN,
) -> None:
    """Assert all history cols have correct lengths in both rows."""
    for col in HISTORY_COLS:
        s_arr = list(summary_row.get(col) or [])
        l_arr = list(latest_row.get(col) or [])
        assert_equal(len(s_arr), summary_len, f"{col} summary length")
        assert_equal(len(l_arr), latest_len,  f"{col} latest length")


def assert_summary_prefix_of_latest(
    summary_row: Dict[str, Any],
    latest_row: Dict[str, Any],
    summary_len: int = SUMMARY_HISTORY_LEN,
) -> None:
    """Assert first summary_len elements of latest match summary."""
    for col in HISTORY_COLS:
        s_arr = list(summary_row.get(col) or [])
        l_arr = list(latest_row.get(col) or [])
        if s_arr != l_arr[:summary_len]:
            raise AssertionError(
                f"{col}: summary[:{summary_len}] != latest[:{summary_len}]  "
                f"summary={s_arr[:4]}  latest={l_arr[:4]}"
            )


def assert_latest_matches_summary_v5(
    spark,
    summary_table: str,
    latest_table: str,
    pk_col: str = "cons_acct_key",
    prt_col: str = "rpt_as_of_mo",
    ts_col: str = "base_ts",
    summary_len: int = SUMMARY_HISTORY_LEN,
    latest_len: int = LATEST_HISTORY_LEN,
) -> None:
    """
    Full-table assertion: latest_summary must hold the most-recent summary row
    per key, with history arrays of the correct lengths and matching prefix.
    """
    summary_df = spark.table(summary_table)
    latest_df  = spark.table(latest_table)

    expected_df = (
        summary_df
        .withColumn("_rn", F.row_number().over(
            Window.partitionBy(pk_col).orderBy(F.col(prt_col).desc(), F.col(ts_col).desc())
        ))
        .filter(F.col("_rn") == 1).drop("_rn")
    )

    expected = {int(r[pk_col]): r.asDict(recursive=True) for r in expected_df.collect()}
    latest   = {int(r[pk_col]): r.asDict(recursive=True) for r in latest_df.collect()}

    missing  = sorted(set(expected) - set(latest))
    extra    = sorted(set(latest) - set(expected))
    mismatches: List[Dict] = []

    for acct in sorted(set(expected) & set(latest)):
        s_row = expected[acct]
        l_row = latest[acct]
        bad_cols = []
        for col, s_val in s_row.items():
            l_val = l_row.get(col)
            if col in HISTORY_COLS:
                s_arr = list(s_val or [])
                l_arr = list(l_val or [])
                if len(s_arr) != summary_len:
                    bad_cols.append(f"{col}:summary_len={len(s_arr)}")
                elif len(l_arr) != latest_len:
                    bad_cols.append(f"{col}:latest_len={len(l_arr)}")
                elif s_arr != l_arr[:summary_len]:
                    bad_cols.append(f"{col}:prefix_mismatch")
            else:
                if l_val != s_val:
                    bad_cols.append(col)
        if bad_cols:
            mismatches.append({"key": acct, "month": s_row.get(prt_col), "cols": bad_cols[:8]})

    if missing or extra or mismatches:
        raise AssertionError(
            f"latest_summary inconsistent with summary (v5 contract)  "
            f"missing_keys={missing[:5]}  extra_keys={extra[:5]}  mismatches={mismatches[:5]}"
        )


# ── Month arithmetic helpers (mirror v5 module helpers) ───────────────────────
def month_to_int(month: str) -> int:
    y, m = month.split("-")
    return int(y) * 12 + int(m)


def int_to_month(val: int) -> str:
    y, m = divmod(val, 12)
    if m == 0:
        m, y = 12, y - 1
    return f"{y:04d}-{m:02d}"


def month_span(start: str, end: str) -> List[str]:
    return [int_to_month(i) for i in range(month_to_int(start), month_to_int(end) + 1)]
