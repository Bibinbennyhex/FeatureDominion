"""
test_v5_multi_account_mixed_cases.py
--------------------------------------
Tests running all four case types for different accounts in a single batch,
plus consecutive backfill and non-contiguous backfill edge cases:

MIXED BATCH
  T1: One batch with Case I + II + III + IV accounts → each processed correctly
  T2: Case I and Case IV accounts in the same batch → no cross-contamination
  T3: Case II and Case III accounts in same batch → each case processed correctly

CONSECUTIVE BACKFILL
  T4: Backfill the same month twice in consecutive runs → second run is idempotent
  T5: Multiple consecutive months backfilled in one run → correct chaining

NON-CONTIGUOUS BACKFILL
  T6: Backfill with gaps in month sequence → only targeted months updated,
      non-targeted summary months have null at those positions

RECOVERY / EDGE CASES
  T7: Source batch with zero rows → pipeline completes gracefully
  T8: All accounts new (no existing summary) → all classified as Case I
  T9: Single account with 36 months → boundary slot [35] correctly populated
"""
from datetime import datetime

from pyspark.sql import functions as F

from v5_contract_utils import (
    HISTORY_COLS,
    LATEST_HISTORY_LEN,
    SUMMARY_HISTORY_LEN,
    assert_equal,
    assert_true,
    assert_history_lengths,
    assert_summary_prefix_of_latest,
    assert_latest_matches_summary_v5,
    history,
    load_v5_module,
    month_to_int,
    int_to_month,
    pad_latest_rows,
)
from v5_test_utils import (
    create_spark_session,
    make_config,
    reset_tables,
    write_source_rows,
    write_summary_rows,
    fetch_single_row,
    build_source_row,
    build_summary_row,
)


def _month_seq(start: str, count: int):
    si = month_to_int(start)
    return [int_to_month(si + i) for i in range(count)]


def test_v5_multi_account_mixed_cases() -> None:
    module = load_v5_module("_v5_mixed_cases")
    spark  = create_spark_session("v5_multi_account_mixed")
    config = make_config("multi_mixed")

    try:
        # ── T1: All four cases in one batch ───────────────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        seed_ts = datetime(2026, 1, 1)
        src_ts  = datetime(2026, 2, 10)

        # Existing data for Case II and Case III accounts
        ex_c2 = build_summary_row(1001, "2026-01", seed_ts, balance=5000,
                                  balance_history=history({0: 5000}, SUMMARY_HISTORY_LEN))
        ex_c3 = build_summary_row(1002, "2026-01", seed_ts, balance=6000,
                                  balance_history=history({0: 6000}, SUMMARY_HISTORY_LEN))
        anchor = build_summary_row(9999, "2020-01", seed_ts, balance=100)
        write_summary_rows(spark, config["destination_table"], [ex_c2, ex_c3, anchor])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([ex_c2, ex_c3]))
        module.preload_run_table_columns(spark, config)

        write_source_rows(spark, config["source_table"], [
            build_source_row(1000, "2026-01", src_ts, balance=1000),     # Case I
            build_source_row(1001, "2026-02", src_ts, balance=4900),     # Case II
            build_source_row(1002, "2025-12", src_ts, balance=5900),     # Case III
            build_source_row(1003, "2025-11", src_ts, balance=3000),     # Case I (oldest)
            build_source_row(1003, "2025-12", src_ts, balance=3100),     # Case IV
            build_source_row(1003, "2026-01", src_ts, balance=3200),     # Case IV
        ])
        module.run_pipeline(spark, config)

        # Case I - 1000
        s1000 = fetch_single_row(spark, config["destination_table"], 1000, "2026-01")
        assert_equal(s1000["balance_am_history"][0], 1000.0, "T1 Case I balance[0]")
        assert_true(all(v is None for v in s1000["balance_am_history"][1:]),
                    "T1 Case I trailing slots None")

        # Case II - 1001
        s1001 = fetch_single_row(spark, config["destination_table"], 1001, "2026-02")
        assert_equal(s1001["balance_am_history"][0], 4900.0, "T1 Case II Feb balance[0]")
        assert_equal(s1001["balance_am_history"][1], 5000.0, "T1 Case II Feb balance[1]=Jan")

        # Case III - 1002 (backfill Dec + patch Jan)
        s1002_dec = fetch_single_row(spark, config["destination_table"], 1002, "2025-12")
        s1002_jan = fetch_single_row(spark, config["destination_table"], 1002, "2026-01")
        assert_equal(s1002_dec["balance_am_history"][0], 5900.0, "T1 Case III Dec balance[0]")
        assert_equal(s1002_jan["balance_am_history"][1], 5900.0, "T1 Case III Jan balance[1] patched")

        # Case IV - 1003 (3 months, newest first in array)
        s1003_jan = fetch_single_row(spark, config["destination_table"], 1003, "2026-01")
        assert_equal(s1003_jan["balance_am_history"][0], 3200.0, "T1 Case IV Jan balance[0]")
        assert_equal(s1003_jan["balance_am_history"][1], 3100.0, "T1 Case IV Jan balance[1]=Dec")
        assert_equal(s1003_jan["balance_am_history"][2], 3000.0, "T1 Case IV Jan balance[2]=Nov")

        assert_latest_matches_summary_v5(
            spark, config["destination_table"], config["latest_history_table"]
        )

        # ── T4: Consecutive backfill of same month is idempotent ──────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        jan = build_summary_row(2001, "2026-01", seed_ts, balance=8000,
                                balance_history=history({0: 8000}, SUMMARY_HISTORY_LEN))
        feb = build_summary_row(2001, "2026-02", seed_ts, balance=7900,
                                balance_history=history({0: 7900, 1: 8000}, SUMMARY_HISTORY_LEN))
        write_summary_rows(spark, config["destination_table"], [jan, feb])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([feb]))
        module.preload_run_table_columns(spark, config)

        bf_ts = datetime(2026, 3, 1)
        for _ in range(2):  # run twice
            write_source_rows(spark, config["source_table"], [
                build_source_row(2001, "2026-01", bf_ts, balance=8200, actual_payment=820),
            ])
            module.run_pipeline(spark, config)

        s_jan_after = fetch_single_row(spark, config["destination_table"], 2001, "2026-01")
        assert_equal(s_jan_after["balance_am_history"][0], 8200.0,
                     "T4 consecutive backfill idempotent result")

        # ── T5: Multiple consecutive months backfilled in one run ─────────────
        reset_tables(spark, config)
        module.cleanup(spark)

        # Seed Oct, Nov, Dec, Jan
        months = ["2025-10", "2025-11", "2025-12", "2026-01"]
        bal_map = {m: float(9000 - i * 100) for i, m in enumerate(months)}
        rows_seed = []
        for i, mo in enumerate(months):
            h = {j: bal_map[months[i - j]] for j in range(i + 1) if i - j >= 0}
            rows_seed.append(build_summary_row(
                2002, mo, seed_ts, balance=bal_map[mo],
                balance_history=history(h, SUMMARY_HISTORY_LEN),
            ))
        write_summary_rows(spark, config["destination_table"], rows_seed)
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([rows_seed[-1]]))
        module.preload_run_table_columns(spark, config)

        bf_ts2 = datetime(2026, 4, 1)
        # Backfill Oct and Nov in one run
        write_source_rows(spark, config["source_table"], [
            build_source_row(2002, "2025-10", bf_ts2, balance=9050, actual_payment=905),
            build_source_row(2002, "2025-11", bf_ts2, balance=8950, actual_payment=895),
        ])
        module.run_pipeline(spark, config)

        s_dec = fetch_single_row(spark, config["destination_table"], 2002, "2025-12")
        s_jan = fetch_single_row(spark, config["destination_table"], 2002, "2026-01")

        assert_equal(s_dec["balance_am_history"][1], 8950.0,
                     "T5 Dec balance[1] patched to corrected Nov")
        assert_equal(s_dec["balance_am_history"][2], 9050.0,
                     "T5 Dec balance[2] patched to corrected Oct")
        assert_equal(s_jan["balance_am_history"][2], 8950.0,
                     "T5 Jan balance[2] patched to corrected Nov")
        assert_equal(s_jan["balance_am_history"][3], 9050.0,
                     "T5 Jan balance[3] patched to corrected Oct")

        # ── T6: Non-contiguous backfill (gap months not in summary untouched) ─
        reset_tables(spark, config)
        module.cleanup(spark)

        # Only have Jul and Sep in summary (no Aug)
        jul = build_summary_row(2003, "2025-07", seed_ts, balance=7000,
                                balance_history=history({0: 7000}, SUMMARY_HISTORY_LEN))
        sep = build_summary_row(2003, "2025-09", seed_ts, balance=6800,
                                balance_history=history({0: 6800, 2: 7000}, SUMMARY_HISTORY_LEN))
        write_summary_rows(spark, config["destination_table"], [jul, sep])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([sep]))
        module.preload_run_table_columns(spark, config)

        bf_ts3 = datetime(2026, 2, 1)
        write_source_rows(spark, config["source_table"], [
            build_source_row(2003, "2025-07", bf_ts3, balance=7100, actual_payment=710),
        ])
        module.run_pipeline(spark, config)

        s_sep = fetch_single_row(spark, config["destination_table"], 2003, "2025-09")
        # Sep[2] = Jul (2 months back) → patched
        assert_equal(s_sep["balance_am_history"][2], 7100.0,
                     "T6 Sep balance[2] = corrected Jul (non-contiguous patched correctly)")
        # Sep[1] = Aug (1 month back, no data) → still None
        assert_true(s_sep["balance_am_history"][1] is None,
                    "T6 Sep balance[1] = None (Aug not in summary, position unchanged)")

        # ── T7: Zero-row source batch → no crash ─────────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)
        module.preload_run_table_columns(spark, config)

        # Write empty source
        from pyspark.sql.types import StructType, StructField, StringType, LongType, TimestampType
        empty_schema = StructType([
            StructField("cons_acct_key",  LongType(),      False),
            StructField("rpt_as_of_mo",   StringType(),    False),
            StructField("base_ts",        TimestampType(), True),
        ])
        spark.createDataFrame([], empty_schema).writeTo(config["source_table"]).createOrReplace()
        module.run_pipeline(spark, config)  # must not raise

        # ── T8: All new accounts ───────────────────────────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)
        module.preload_run_table_columns(spark, config)

        multi_ts = datetime(2026, 1, 15)
        write_source_rows(spark, config["source_table"], [
            build_source_row(3001, "2026-01", multi_ts, balance=1000),
            build_source_row(3002, "2026-01", multi_ts, balance=2000),
            build_source_row(3003, "2026-01", multi_ts, balance=3000),
        ])
        classified = module.load_and_classify_accounts(spark, config)
        case_types = {int(r["cons_acct_key"]): r["case_type"]
                      for r in classified.select("cons_acct_key", "case_type").collect()}
        for acct in [3001, 3002, 3003]:
            assert_equal(case_types[acct], "CASE_I", f"T8 acct={acct} classified as Case I")

        # ── T9: 36-month boundary slot [35] ──────────────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)
        module.preload_run_table_columns(spark, config)

        months_36 = _month_seq("2023-02", 36)  # 36 months ending 2026-01
        rows_36 = [
            build_source_row(4001, mo, multi_ts, balance=float(10000 - i * 10))
            for i, mo in enumerate(months_36)
        ]
        write_source_rows(spark, config["source_table"], rows_36)
        module.run_pipeline(spark, config)

        s_last = fetch_single_row(spark, config["destination_table"], 4001, months_36[-1])
        assert_equal(s_last["balance_am_history"][35], float(10000),
                     "T9 slot[35] (oldest of 36) = first month value")
        assert_true(len(s_last["balance_am_history"]) == SUMMARY_HISTORY_LEN,
                    "T9 exactly 36 slots in summary array")

        assert_latest_matches_summary_v5(
            spark, config["destination_table"], config["latest_history_table"]
        )

        print("[PASS] test_v5_multi_account_mixed_cases")
    finally:
        spark.stop()


if __name__ == "__main__":
    test_v5_multi_account_mixed_cases()
