"""
test_v5_idempotency.py
-----------------------
Verifies that re-running the pipeline on already-processed data
produces byte-for-byte identical results for all four cases:
  T1: Idempotency of Case I  (single new account)
  T2: Idempotency of Case II (forward month)
  T3: Idempotency of Case III backfill
  T4: Idempotency of soft-delete
  T5: Idempotency of Case IV bulk load
  T6: Multi-case batch idempotency (I+II+III+IV in one run, repeated twice)

Idempotency means:
  - Row count unchanged
  - All scalar columns unchanged
  - All history arrays identical (element-wise)
  - latest_summary unchanged
"""
from datetime import datetime
from typing import Dict, Any, List

from pyspark.sql import functions as F

from v5_contract_utils import (
    HISTORY_COLS,
    LATEST_HISTORY_LEN,
    SUMMARY_HISTORY_LEN,
    assert_equal,
    assert_true,
    assert_latest_matches_summary_v5,
    history,
    load_v5_module,
    pad_latest_rows,
)
from v5_test_utils import (
    create_spark_session,
    make_config,
    reset_tables,
    write_source_rows,
    write_summary_rows,
    fetch_single_row,
    build_source_row,
    build_summary_row,
)


def _snapshot(spark, table: str) -> Dict[int, Dict[str, Any]]:
    """Collect entire table keyed by (cons_acct_key, rpt_as_of_mo)."""
    return {
        (int(r["cons_acct_key"]), r["rpt_as_of_mo"]): r.asDict(recursive=True)
        for r in spark.table(table).collect()
    }


def _assert_snapshots_equal(snap1, snap2, label: str) -> None:
    assert_equal(set(snap1.keys()), set(snap2.keys()), f"{label}: key set")
    for k in snap1:
        r1, r2 = snap1[k], snap2[k]
        for col in r1:
            v1, v2 = r1[col], r2[col]
            if isinstance(v1, list):
                assert_equal(list(v1), list(v2), f"{label} key={k} col={col}")
            else:
                assert_equal(v1, v2, f"{label} key={k} col={col}")


def test_v5_idempotency() -> None:
    module = load_v5_module("_v5_idempotency")
    spark  = create_spark_session("v5_idempotency")
    config = make_config("idem")

    try:
        # ── T1: Case I idempotency ────────────────────────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)
        module.preload_run_table_columns(spark, config)

        ts = datetime(2026, 2, 1)
        write_source_rows(spark, config["source_table"], [
            build_source_row(9001, "2026-01", ts, balance=5000, actual_payment=500),
        ])
        module.run_pipeline(spark, config)

        snap1_s = _snapshot(spark, config["destination_table"])
        snap1_l = _snapshot(spark, config["latest_history_table"])

        # Re-run same source
        module.run_pipeline(spark, config)

        snap2_s = _snapshot(spark, config["destination_table"])
        snap2_l = _snapshot(spark, config["latest_history_table"])

        _assert_snapshots_equal(snap1_s, snap2_s, "T1 Case I summary")
        _assert_snapshots_equal(snap1_l, snap2_l, "T1 Case I latest_summary")

        # ── T2: Case II idempotency ───────────────────────────────────────────
        fwd_ts = datetime(2026, 3, 1)
        write_source_rows(spark, config["source_table"], [
            build_source_row(9001, "2026-02", fwd_ts, balance=4800, actual_payment=480),
        ])
        module.run_pipeline(spark, config)

        snap3_s = _snapshot(spark, config["destination_table"])
        snap3_l = _snapshot(spark, config["latest_history_table"])

        module.run_pipeline(spark, config)

        snap4_s = _snapshot(spark, config["destination_table"])
        snap4_l = _snapshot(spark, config["latest_history_table"])

        _assert_snapshots_equal(snap3_s, snap4_s, "T2 Case II summary")
        _assert_snapshots_equal(snap3_l, snap4_l, "T2 Case II latest_summary")

        # ── T3: Case III backfill idempotency ─────────────────────────────────
        bf_ts = datetime(2026, 4, 1)
        write_source_rows(spark, config["source_table"], [
            build_source_row(9001, "2026-01", bf_ts, balance=5100, actual_payment=510),
        ])
        module.run_pipeline(spark, config)

        snap5_s = _snapshot(spark, config["destination_table"])
        snap5_l = _snapshot(spark, config["latest_history_table"])

        module.run_pipeline(spark, config)

        snap6_s = _snapshot(spark, config["destination_table"])
        snap6_l = _snapshot(spark, config["latest_history_table"])

        _assert_snapshots_equal(snap5_s, snap6_s, "T3 Case III summary")
        _assert_snapshots_equal(snap5_l, snap6_l, "T3 Case III latest_summary")

        # ── T4: Soft-delete idempotency ───────────────────────────────────────
        del_ts = datetime(2026, 5, 1)
        write_source_rows(spark, config["source_table"], [
            build_source_row(9001, "2026-01", del_ts, soft_del_cd="1"),
        ])
        module.run_pipeline(spark, config)

        snap7_s = _snapshot(spark, config["destination_table"])
        snap7_l = _snapshot(spark, config["latest_history_table"])

        module.run_pipeline(spark, config)

        snap8_s = _snapshot(spark, config["destination_table"])
        snap8_l = _snapshot(spark, config["latest_history_table"])

        _assert_snapshots_equal(snap7_s, snap8_s, "T4 soft-delete summary")
        _assert_snapshots_equal(snap7_l, snap8_l, "T4 soft-delete latest_summary")

        # ── T5: Case IV (bulk) idempotency ────────────────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)
        module.preload_run_table_columns(spark, config)

        bulk_ts = datetime(2026, 3, 1)
        bulk_rows = [
            build_source_row(9002, f"2025-{m:02d}", bulk_ts,
                             balance=float(10000 - (m - 1) * 100), actual_payment=500.0)
            for m in range(1, 13)
        ]
        write_source_rows(spark, config["source_table"], bulk_rows)
        module.run_pipeline(spark, config)

        snap9_s  = _snapshot(spark, config["destination_table"])
        snap9_l  = _snapshot(spark, config["latest_history_table"])

        module.run_pipeline(spark, config)

        snap10_s = _snapshot(spark, config["destination_table"])
        snap10_l = _snapshot(spark, config["latest_history_table"])

        _assert_snapshots_equal(snap9_s,  snap10_s, "T5 Case IV summary")
        _assert_snapshots_equal(snap9_l,  snap10_l, "T5 Case IV latest_summary")

        # ── T6: Mixed-case batch idempotency ──────────────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)
        module.preload_run_table_columns(spark, config)

        # Seed existing data for backfill account
        seed_ts = datetime(2025, 12, 1)
        existing = build_summary_row(9101, "2025-12", seed_ts, balance=6000)
        write_summary_rows(spark, config["destination_table"], [existing])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([existing]))
        module.preload_run_table_columns(spark, config)

        mixed_ts = datetime(2026, 2, 1)
        mixed_rows = [
            build_source_row(9100, "2026-01", mixed_ts, balance=1000),            # Case I
            build_source_row(9101, "2026-01", mixed_ts, balance=6100),            # Case II
            build_source_row(9101, "2025-11", mixed_ts, balance=5900),            # Case III
            build_source_row(9102, "2025-10", mixed_ts, balance=2000),            # Case I
            build_source_row(9102, "2025-11", mixed_ts, balance=2100),            # Case IV
            build_source_row(9102, "2025-12", mixed_ts, balance=2200),            # Case IV
        ]
        write_source_rows(spark, config["source_table"], mixed_rows)
        module.run_pipeline(spark, config)

        snap_m1_s = _snapshot(spark, config["destination_table"])
        snap_m1_l = _snapshot(spark, config["latest_history_table"])

        module.run_pipeline(spark, config)

        snap_m2_s = _snapshot(spark, config["destination_table"])
        snap_m2_l = _snapshot(spark, config["latest_history_table"])

        _assert_snapshots_equal(snap_m1_s, snap_m2_s, "T6 mixed summary")
        _assert_snapshots_equal(snap_m1_l, snap_m2_l, "T6 mixed latest_summary")

        print("[PASS] test_v5_idempotency")
    finally:
        spark.stop()


if __name__ == "__main__":
    test_v5_idempotency()
