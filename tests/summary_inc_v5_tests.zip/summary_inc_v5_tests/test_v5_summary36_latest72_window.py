"""
test_v5_summary36_latest72_window.py
--------------------------------------
Verifies the v5 36/72 array-length contract:
  - summary history cols are always exactly 36 elements
  - latest_summary history cols are always exactly 72 elements
  - First 36 elements of latest must equal summary
  - Sentinel values beyond index 35 in latest are preserved through updates
Covers both a same-month update (CASE_III / MONTH_DIFF=0) and a forward update
(CASE_II).
"""
from datetime import datetime
from pathlib import Path

from v5_contract_utils import (
    HISTORY_COLS,
    LATEST_HISTORY_LEN,
    SUMMARY_HISTORY_LEN,
    assert_equal,
    assert_history_lengths,
    assert_summary_prefix_of_latest,
    assert_true,
    history,
    load_v5_module,
    pad_latest_rows,
)
from v5_test_utils import (
    create_spark_session,
    make_config,
    reset_tables,
    write_source_rows,
    write_summary_rows,
    fetch_single_row,
    build_source_row,
    build_summary_row,
)


def _h72(slot_map):
    return history(slot_map, length=LATEST_HISTORY_LEN)


def _h36(slot_map):
    return history(slot_map, length=SUMMARY_HISTORY_LEN)


def test_v5_summary36_latest72_window() -> None:
    module = load_v5_module("_v5_36_72_window")
    spark  = create_spark_session("v5_summary36_latest72_window")
    config = make_config("win3672", history_length=36, latest_history_window_months=72)

    # Sentinels to check preservation at positions 36-71
    sentinel = {
        "balance_am_history":          500.0,
        "actual_payment_am_history":   50.0,
        "credit_limit_am_history":     4500.0,
        "past_due_am_history":         0.0,
        "days_past_due_history":       30,
        "payment_rating_cd_history":   "2",
        "asset_class_cd_4in_history":  "B",
    }
    acct = 990001
    seed_ts   = datetime(2026, 1, 1)
    update_ts = datetime(2026, 2, 1, 12)

    try:
        reset_tables(spark, config)
        module.cleanup(spark)
        module.preload_run_table_columns(spark, config)

        # Seed summary (36 slots) and latest_summary (72 slots) with sentinel at index 36
        summary_seed = build_summary_row(
            cons_acct_key=acct, rpt_as_of_mo="2026-01", base_ts=seed_ts,
            balance=1000, actual_payment=100,
            balance_history=_h36({0: 1000, 1: 900}),
            payment_history=_h36({0: 100, 1: 90}),
            credit_history=_h36({0: 5000}),
            past_due_history=_h36({0: 0}),
            dpd_history=_h36({0: 0}),
            rating_history=_h36({0: "0", 1: "0"}),
            asset_history=_h36({0: "A", 1: "A"}),
        )
        # latest has 72 slots; slot 36 carries sentinel
        latest_seed = build_summary_row(
            cons_acct_key=acct, rpt_as_of_mo="2026-01", base_ts=seed_ts,
            balance=1000, actual_payment=100,
            balance_history=_h72({0: 1000, 1: 900, 36: sentinel["balance_am_history"]}),
            payment_history=_h72({0: 100,  1: 90,  36: sentinel["actual_payment_am_history"]}),
            credit_history=_h72({0: 5000,           36: sentinel["credit_limit_am_history"]}),
            past_due_history=_h72({0: 0,             36: sentinel["past_due_am_history"]}),
            dpd_history=_h72({0: 0,                  36: sentinel["days_past_due_history"]}),
            rating_history=_h72({0: "0", 1: "0",    36: sentinel["payment_rating_cd_history"]}),
            asset_history=_h72({0: "A", 1: "A",     36: sentinel["asset_class_cd_4in_history"]}),
            history_len=LATEST_HISTORY_LEN,
        )

        write_summary_rows(spark, config["destination_table"], [summary_seed])
        write_summary_rows(spark, config["latest_history_table"], [latest_seed])

        # Same-month update (CASE_III MONTH_DIFF=0) via source row with newer ts
        write_source_rows(spark, config["source_table"], [
            build_source_row(acct, "2026-01", update_ts, balance=1100, actual_payment=120),
        ])
        module.run_pipeline(spark, config)

        s_after = fetch_single_row(spark, config["destination_table"], acct, "2026-01")
        l_after = fetch_single_row(spark, config["latest_history_table"], acct, "2026-01")

        # Length contract
        assert_history_lengths(s_after, l_after)

        # Updated values at index 0
        assert_equal(s_after["balance_am_history"][0], 1100.0, "summary balance[0] after update")
        assert_equal(l_after["balance_am_history"][0], 1100.0, "latest balance[0] after update")

        # Prefix match
        assert_summary_prefix_of_latest(s_after, l_after)

        # Sentinel at index 36 preserved
        for col, sentinel_val in sentinel.items():
            actual = l_after[col][36]
            assert_equal(actual, sentinel_val, f"sentinel at index 36 preserved: {col}")

        print("[PASS] test_v5_summary36_latest72_window")
    finally:
        spark.stop()


if __name__ == "__main__":
    test_v5_summary36_latest72_window()
