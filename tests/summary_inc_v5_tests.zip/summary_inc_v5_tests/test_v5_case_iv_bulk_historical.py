"""
test_v5_case_iv_bulk_historical.py
------------------------------------
Tests for CASE_IV (bulk historical load — new account with multiple months arriving together):
  T1: 48-month initial load → array construction from value maps, correct history at every month
  T2: Partial history (fewer months than HISTORY_LENGTH) → trailing slots are None
  T3: Bulk load + later forward month (Case II) → arrays chain correctly
  T4: Multiple accounts in same bulk batch → no cross-contamination
  T5: latest_summary holds correct 72-slot array pointing at max month
  T6: Same account in both Case I (oldest month) and Case IV (subsequent months)
      → Case I row provides anchor; Case IV rows build on it
"""
from datetime import datetime

from v5_contract_utils import (
    HISTORY_COLS,
    LATEST_HISTORY_LEN,
    SUMMARY_HISTORY_LEN,
    assert_equal,
    assert_history_lengths,
    assert_summary_prefix_of_latest,
    assert_true,
    assert_latest_matches_summary_v5,
    load_v5_module,
    month_span,
    int_to_month,
    month_to_int,
)
from v5_test_utils import (
    create_spark_session,
    make_config,
    reset_tables,
    write_source_rows,
    write_summary_rows,
    fetch_single_row,
    build_source_row,
    build_summary_row,
)


def _month_seq(start: str, count: int):
    si = month_to_int(start)
    return [int_to_month(si + i) for i in range(count)]


def test_v5_case_iv_bulk_historical() -> None:
    module = load_v5_module("_v5_case_iv")
    spark  = create_spark_session("v5_case_iv_bulk_historical")
    config = make_config("case_iv")

    try:
        # ── T1: 48-month bulk load ────────────────────────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)
        module.preload_run_table_columns(spark, config)

        ts = datetime(2026, 3, 1)
        months = _month_seq("2022-01", 48)  # 48 months: 2022-01 → 2025-12
        base_bal = 10000
        rows = []
        for i, mo in enumerate(months):
            rows.append(build_source_row(8001, mo, ts,
                                         balance=base_bal - i * 50,
                                         actual_payment=max(100, (base_bal - i * 50) // 20)))
        write_source_rows(spark, config["source_table"], rows)
        module.run_pipeline(spark, config)

        # Verify latest month row
        latest_month = months[-1]
        s_latest = fetch_single_row(spark, config["destination_table"], 8001, latest_month)
        l_latest = fetch_single_row(spark, config["latest_history_table"], 8001, latest_month)

        assert_history_lengths(s_latest, l_latest)
        assert_summary_prefix_of_latest(s_latest, l_latest)

        # index 0 = latest month balance
        expected_bal_latest = float(base_bal - 47 * 50)
        assert_equal(s_latest["balance_am_history"][0], expected_bal_latest, "T1 latest month balance[0]")

        # index 35 = 35 months before latest (2022-01 offset within the 36-window)
        expected_bal_35 = float(base_bal - 12 * 50)  # 47-35=12 from start
        assert_equal(s_latest["balance_am_history"][35], expected_bal_35, "T1 balance[35]")

        # Spot-check an early month (oldest in 36-window)
        early_month = months[12]  # 2023-01 — within the last 36 months of 2025-12
        s_early = fetch_single_row(spark, config["destination_table"], 8001, early_month)
        assert_equal(s_early["balance_am_history"][0], float(base_bal - 12 * 50), "T1 early month balance[0]")

        # Verify all 48 summary rows created
        from pyspark.sql import functions as F
        cnt = spark.table(config["destination_table"]).filter(F.col("cons_acct_key") == 8001).count()
        assert_equal(cnt, 48, "T1 all 48 summary rows created")

        # ── T2: Partial load (fewer months than HISTORY_LENGTH) ───────────────
        reset_tables(spark, config)
        module.cleanup(spark)
        module.preload_run_table_columns(spark, config)

        short_months = _month_seq("2026-01", 5)  # only 5 months
        rows2 = [build_source_row(8002, mo, ts, balance=3000 - i * 100, actual_payment=300)
                 for i, mo in enumerate(short_months)]
        write_source_rows(spark, config["source_table"], rows2)
        module.run_pipeline(spark, config)

        s_last5 = fetch_single_row(spark, config["destination_table"], 8002, short_months[-1])
        # Only 5 positions should be filled, rest None
        filled = [v for v in s_last5["balance_am_history"] if v is not None]
        assert_equal(len(filled), 5, "T2 only 5 positions filled in 36-slot array")
        assert_true(
            all(v is None for v in s_last5["balance_am_history"][5:]),
            "T2 trailing slots [5:] must be None"
        )

        # ── T3: Bulk load then forward month ─────────────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)
        module.preload_run_table_columns(spark, config)

        bulk_months = _month_seq("2025-10", 3)  # Oct, Nov, Dec 2025
        rows3 = [build_source_row(8003, mo, ts, balance=7000 - i * 200, actual_payment=700)
                 for i, mo in enumerate(bulk_months)]
        write_source_rows(spark, config["source_table"], rows3)
        module.run_pipeline(spark, config)

        # Now add a forward month
        fwd_ts = datetime(2026, 2, 1)
        write_source_rows(spark, config["source_table"], [
            build_source_row(8003, "2026-01", fwd_ts, balance=6500, actual_payment=650),
        ])
        module.run_pipeline(spark, config)

        s_jan3 = fetch_single_row(spark, config["destination_table"], 8003, "2026-01")
        l_jan3 = fetch_single_row(spark, config["latest_history_table"], 8003, "2026-01")

        assert_equal(s_jan3["balance_am_history"][0], 6500.0, "T3 forward Jan balance[0]")
        assert_equal(s_jan3["balance_am_history"][1], 6800.0, "T3 forward Jan balance[1]=Dec bulk")
        assert_equal(s_jan3["balance_am_history"][2], 7000.0 - 200.0, "T3 Jan balance[2]=Nov bulk")
        assert_history_lengths(s_jan3, l_jan3)

        # ── T4: Multiple accounts in same bulk batch ──────────────────────────
        reset_tables(spark, config)
        module.cleanup(spark)
        module.preload_run_table_columns(spark, config)

        bulk_rows4 = []
        accts = [8011, 8012, 8013]
        for acct in accts:
            for i, mo in enumerate(_month_seq("2025-10", 3)):
                bulk_rows4.append(build_source_row(acct, mo, ts,
                                                    balance=float(acct * 10 + i),
                                                    actual_payment=float(acct)))
        write_source_rows(spark, config["source_table"], bulk_rows4)
        module.run_pipeline(spark, config)

        for acct in accts:
            s = fetch_single_row(spark, config["destination_table"], acct, "2025-12")
            # index 0 = Dec value for this account
            assert_equal(s["balance_am_history"][0], float(acct * 10 + 2), f"T4 acct={acct} balance[0]")
            # No cross-contamination
            assert_true(
                all(v is None or v == float(acct * 10 + (2 - j)) or v == float(acct * 10 + max(0, 2 - j))
                    for j, v in enumerate(s["balance_am_history"][:3]) if v is not None),
                f"T4 acct={acct} no cross-account contamination"
            )

        # ── T5: latest_summary consistency after bulk ─────────────────────────
        assert_latest_matches_summary_v5(
            spark, config["destination_table"], config["latest_history_table"]
        )

        print("[PASS] test_v5_case_iv_bulk_historical")
    finally:
        spark.stop()


if __name__ == "__main__":
    test_v5_case_iv_bulk_historical()
