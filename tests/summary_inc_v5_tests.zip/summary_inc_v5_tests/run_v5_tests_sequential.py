"""
run_v5_tests_sequential.py
---------------------------
Sequential runner for the summary_inc_v5 test suite.

Usage:
    python run_v5_tests_sequential.py
    python run_v5_tests_sequential.py --tests test_v5_module_smoke test_v5_idempotency
    V5_PIPELINE_SCRIPT=/path/to/summary_inc_v5.py python run_v5_tests_sequential.py

Environment variables:
    V5_PIPELINE_SCRIPT  Override path to summary_inc_v5.py
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path


TESTS_DIR = Path(__file__).resolve().parent
ARTIFACT_ROOT = TESTS_DIR / "artifacts" / "v5_sequential"

# Ordered test list – smoke first, helpers before integration, integration before perf
ORDERED_TESTS = [
    "test_v5_module_smoke.py",
    "test_v5_watermark_tracker.py",            # also covers validate_config + helpers
    "test_v5_case_end_to_end_smoke.py",
    "test_v5_summary36_latest72_window.py",
    "test_v5_case_i_new_accounts.py",
    "test_v5_case_ii_forward_entries.py",
    "test_v5_case_iii_backfill_hot_cold.py",
    "test_v5_soft_delete.py",
    "test_v5_case_iv_bulk_historical.py",
    "test_v5_idempotency.py",
    "test_v5_latest_summary_consistency.py",
    "test_v5_working_set_context_tables.py",
    "test_v5_lane_routing_and_invariants.py",
    "test_v5_multi_account_mixed_cases.py",
]


def _discover_tests() -> list[str]:
    """Return all test_v5_*.py files in TESTS_DIR, sorted."""
    return sorted(p.name for p in TESTS_DIR.glob("test_v5_*.py"))


def _run_test(name: str, env: dict, run_dir: Path) -> dict:
    log_path = run_dir / f"{name}.log"
    cmd = [sys.executable, str(TESTS_DIR / name)]
    started = time.perf_counter()
    rc = 1
    stdout_lines = []
    try:
        proc = subprocess.Popen(
            cmd,
            cwd=str(TESTS_DIR),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            env=env,
        )
        assert proc.stdout is not None
        for line in proc.stdout:
            print(line, end="", flush=True)
            stdout_lines.append(line)
        rc = proc.wait()
    except Exception as exc:
        stdout_lines.append(f"[runner] failed to launch: {exc}\n")
        rc = 1

    log_path.write_text("".join(stdout_lines), encoding="utf-8")
    duration = round(time.perf_counter() - started, 2)
    return {
        "test":         name,
        "status":       "PASS" if rc == 0 else "FAIL",
        "exit_code":    rc,
        "duration_sec": duration,
        "log":          log_path.name,
    }


def _format_table(results: list[dict]) -> str:
    headers  = ["test", "status", "duration_sec", "exit_code"]
    widths   = {h: max(len(h), max(len(str(r[h])) for r in results)) for h in headers}
    sep_line = "-+-".join("-" * widths[h] for h in headers)
    hdr_line = " | ".join(h.ljust(widths[h]) for h in headers)
    rows     = [" | ".join(str(r[h]).ljust(widths[h]) for h in headers) for r in results]
    return "\n".join([hdr_line, sep_line] + rows)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run v5 summary_inc tests sequentially")
    parser.add_argument(
        "--tests", nargs="*",
        help="Specific test file names to run (default: all ordered tests)"
    )
    parser.add_argument(
        "--pipeline-script", default="",
        help="Path to summary_inc_v5.py (also settable via V5_PIPELINE_SCRIPT env var)"
    )
    parser.add_argument(
        "--discover", action="store_true",
        help="Run all test_v5_*.py discovered files instead of the ordered list"
    )
    args = parser.parse_args(argv)

    tests_to_run: list[str]
    if args.tests:
        # Normalise: allow passing without .py
        tests_to_run = [t if t.endswith(".py") else f"{t}.py" for t in args.tests]
    elif args.discover:
        tests_to_run = _discover_tests()
    else:
        tests_to_run = ORDERED_TESTS

    # Verify all requested files exist
    missing = [t for t in tests_to_run if not (TESTS_DIR / t).exists()]
    if missing:
        print(f"ERROR: test files not found: {missing}", file=sys.stderr)
        return 1

    run_id  = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_dir = ARTIFACT_ROOT / f"run_{run_id}"
    run_dir.mkdir(parents=True, exist_ok=True)

    env = dict(os.environ)
    env["PYTHONUNBUFFERED"] = "1"
    if args.pipeline_script:
        env["V5_PIPELINE_SCRIPT"] = args.pipeline_script
    elif not env.get("V5_PIPELINE_SCRIPT"):
        # Auto-detect: check for co-located summary_inc_v5.py
        co = TESTS_DIR / "summary_inc_v5.py"
        if co.exists():
            env["V5_PIPELINE_SCRIPT"] = str(co)

    print(f"=== summary_inc_v5 test suite  run={run_id} ===")
    print(f"    tests_dir: {TESTS_DIR}")
    v5_path = env.get("V5_PIPELINE_SCRIPT", "<auto-detect>")
    print(f"    pipeline:  {v5_path}")
    print(f"    run_dir:   {run_dir}")
    print(f"    tests:     {len(tests_to_run)}")
    print()

    results = []
    for idx, name in enumerate(tests_to_run, 1):
        print(f"[{idx:02d}/{len(tests_to_run):02d}] {name}")
        result = _run_test(name, env, run_dir)
        results.append(result)
        status_tag = "✓" if result["status"] == "PASS" else "✗"
        print(f"       {status_tag} {result['status']}  ({result['duration_sec']}s)\n")

    # Summary
    print("=" * 70)
    print(_format_table(results))
    print()

    total   = len(results)
    passed  = sum(1 for r in results if r["status"] == "PASS")
    failed  = total - passed
    overall = "PASS" if failed == 0 else "FAIL"
    print(f"TOTAL={total}  PASS={passed}  FAIL={failed}  [{overall}]")
    print(f"artifacts: {run_dir}")

    payload = {
        "run_id":          run_id,
        "run_dir":         str(run_dir),
        "v5_pipeline":     v5_path,
        "total":           total,
        "passed":          passed,
        "failed":          failed,
        "overall_status":  overall,
        "results":         results,
    }
    (run_dir / "summary.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    (run_dir / "summary.txt").write_text(
        _format_table(results) + f"\n\nTOTAL={total} PASS={passed} FAIL={failed}\n",
        encoding="utf-8",
    )

    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
