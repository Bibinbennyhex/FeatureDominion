"""
test_v5_case_end_to_end_smoke.py
---------------------------------
Two-run smoke test exercising the core case path for a single account:
  Run 1: new account (Case I)  →  summary row created, latest_summary created
  Run 2: forward month (Case II) → summary row appended, latest updated,
                                    history arrays propagated correctly
  Run 3: backfill (Case III)   → older month inserted, future rows patched
"""
from datetime import datetime
from pathlib import Path

from v5_contract_utils import (
    HISTORY_COLS,
    LATEST_HISTORY_LEN,
    SUMMARY_HISTORY_LEN,
    assert_true,
    assert_equal,
    assert_history_lengths,
    assert_summary_prefix_of_latest,
    assert_latest_matches_summary_v5,
    load_v5_module,
    pad_latest_rows,
)
from v5_test_utils import (
    create_spark_session,
    make_config,
    reset_tables,
    write_source_rows,
    write_summary_rows,
    fetch_single_row,
    build_source_row,
    build_summary_row,
)


def test_v5_case_end_to_end_smoke() -> None:
    module = load_v5_module("_v5_smoke_e2e")
    spark  = create_spark_session("v5_case_end_to_end_smoke")
    config = make_config("e2e_smoke")

    try:
        reset_tables(spark, config)
        module.cleanup(spark)
        module.preload_run_table_columns(spark, config)

        # Anchor row so watermark detection works when summary is empty
        anchor_ts = datetime(2020, 1, 1)
        anchor = build_summary_row(990999, "2020-01", anchor_ts, balance=100)
        write_summary_rows(spark, config["destination_table"], [anchor])
        write_summary_rows(spark, config["latest_history_table"], pad_latest_rows([anchor], LATEST_HISTORY_LEN))

        # ── Run 1: Case I (brand new account) ────────────────────────────────
        ts1 = datetime(2026, 1, 5)
        write_source_rows(spark, config["source_table"], [
            build_source_row(1001, "2026-01", ts1, balance=5000, actual_payment=100),
        ])
        module.cleanup(spark)
        module.run_pipeline(spark, config)

        s_jan = fetch_single_row(spark, config["destination_table"], 1001, "2026-01")
        l_jan = fetch_single_row(spark, config["latest_history_table"], 1001, "2026-01")

        assert_equal(s_jan["balance_am_history"][0], 5000.0, "Case I summary balance[0]")
        assert_history_lengths(s_jan, l_jan)
        assert_summary_prefix_of_latest(s_jan, l_jan)
        assert_true(all(v is None for v in s_jan["balance_am_history"][1:]),
                    "Case I history slots [1:] should be None")

        # ── Run 2: Case II (forward month) ───────────────────────────────────
        ts2 = datetime(2026, 2, 5)
        write_source_rows(spark, config["source_table"], [
            build_source_row(1001, "2026-02", ts2, balance=4800, actual_payment=200),
        ])
        module.run_pipeline(spark, config)

        s_feb = fetch_single_row(spark, config["destination_table"], 1001, "2026-02")
        l_feb = fetch_single_row(spark, config["latest_history_table"], 1001, "2026-02")

        assert_equal(s_feb["balance_am_history"][0], 4800.0, "Case II summary balance[0]")
        assert_equal(s_feb["balance_am_history"][1], 5000.0, "Case II summary balance[1] carries Jan")
        assert_equal(l_feb["balance_am_history"][0], 4800.0, "Case II latest balance[0]")
        assert_equal(l_feb["balance_am_history"][1], 5000.0, "Case II latest balance[1]")
        assert_history_lengths(s_feb, l_feb)
        assert_summary_prefix_of_latest(s_feb, l_feb)

        # ── Run 3: Case III (backfill Jan with corrected data) ───────────────
        ts3 = datetime(2026, 3, 1)
        write_source_rows(spark, config["source_table"], [
            build_source_row(1001, "2026-01", ts3, balance=5200, actual_payment=120),
        ])
        module.run_pipeline(spark, config)

        s_jan_bf = fetch_single_row(spark, config["destination_table"], 1001, "2026-01")
        s_feb_bf = fetch_single_row(spark, config["destination_table"], 1001, "2026-02")
        l_feb_bf = fetch_single_row(spark, config["latest_history_table"], 1001, "2026-02")

        # Jan row updated
        assert_equal(s_jan_bf["balance_am_history"][0], 5200.0, "Case III backfilled Jan balance[0]")
        # Feb row's [1] (= Jan offset) patched to backfilled value
        assert_equal(s_feb_bf["balance_am_history"][1], 5200.0,
                     "Case III forward-propagated to Feb balance[1]")
        assert_equal(l_feb_bf["balance_am_history"][1], 5200.0,
                     "Case III forward-propagated to latest_summary Feb balance[1]")
        assert_history_lengths(s_feb_bf, l_feb_bf)
        assert_latest_matches_summary_v5(spark, config["destination_table"], config["latest_history_table"])

        print("[PASS] test_v5_case_end_to_end_smoke")
    finally:
        spark.stop()


if __name__ == "__main__":
    test_v5_case_end_to_end_smoke()
