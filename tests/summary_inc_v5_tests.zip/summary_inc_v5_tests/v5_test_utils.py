"""
v5_test_utils.py
----------------
Spark session factory, table helpers, and row builders for summary_inc_v5 tests.

All row builders mirror the domain schema used in the v4 test suite, extended for
the v5 contract (soft_del_cd present in every builder).
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import (
    ArrayType,
    DoubleType,
    IntegerType,
    LongType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)

from v5_contract_utils import (
    HISTORY_COLS,
    LATEST_HISTORY_LEN,
    SUMMARY_HISTORY_LEN,
    history,
    pad_history_array,
)


# ── Spark ─────────────────────────────────────────────────────────────────────
def create_spark_session(app_name: str = "summary_inc_v5_test") -> SparkSession:
    return (
        SparkSession.builder
        .appName(app_name)
        .master("local[2]")
        .config("spark.sql.shuffle.partitions", "4")
        .config("spark.default.parallelism", "4")
        .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
        .config("spark.sql.catalog.spark_catalog", "org.apache.iceberg.spark.SparkSessionCatalog")
        .config("spark.sql.catalog.spark_catalog.type", "hive")
        .config("spark.sql.catalog.temp_catalog", "org.apache.iceberg.spark.SparkCatalog")
        .config("spark.sql.catalog.temp_catalog.type", "in-memory")
        .config("spark.sql.catalog.execution_catalog", "org.apache.iceberg.spark.SparkCatalog")
        .config("spark.sql.catalog.execution_catalog.type", "in-memory")
        .config("spark.sql.catalog.prod_catalog", "org.apache.iceberg.spark.SparkCatalog")
        .config("spark.sql.catalog.prod_catalog.type", "in-memory")
        .config("spark.sql.warehouse.dir", f"/tmp/spark_warehouse_{app_name}")
        .enableHiveSupport()
        .getOrCreate()
    )


# ── Schema helpers ────────────────────────────────────────────────────────────
def _history_field(name: str, element_type) -> StructField:
    return StructField(name, ArrayType(element_type, True), True)


def _summary_schema() -> StructType:
    return StructType([
        StructField("cons_acct_key",       LongType(),      False),
        StructField("rpt_as_of_mo",        StringType(),    False),
        StructField("base_ts",             TimestampType(), True),
        StructField("balance_am",          DoubleType(),    True),
        StructField("actual_payment_am",   DoubleType(),    True),
        StructField("credit_limit_am",     DoubleType(),    True),
        StructField("past_due_am",         DoubleType(),    True),
        StructField("days_past_due",       IntegerType(),   True),
        StructField("payment_rating_cd",   StringType(),    True),
        StructField("asset_class_cd_4in",  StringType(),    True),
        StructField("soft_del_cd",         StringType(),    True),
        StructField("payment_history_grid", StringType(),   True),
        _history_field("balance_am_history",          DoubleType()),
        _history_field("actual_payment_am_history",   DoubleType()),
        _history_field("credit_limit_am_history",     DoubleType()),
        _history_field("past_due_am_history",         DoubleType()),
        _history_field("days_past_due_history",       IntegerType()),
        _history_field("payment_rating_cd_history",   StringType()),
        _history_field("asset_class_cd_4in_history",  StringType()),
    ])


def _source_schema() -> StructType:
    return StructType([
        StructField("cons_acct_key",      LongType(),      False),
        StructField("rpt_as_of_mo",       StringType(),    False),
        StructField("base_ts",            TimestampType(), True),
        StructField("balance_am",         DoubleType(),    True),
        StructField("actual_payment_am",  DoubleType(),    True),
        StructField("credit_limit_am",    DoubleType(),    True),
        StructField("past_due_am",        DoubleType(),    True),
        StructField("days_past_due",      IntegerType(),   True),
        StructField("payment_rating_cd",  StringType(),    True),
        StructField("asset_class_cd_4in", StringType(),    True),
        StructField("soft_del_cd",        StringType(),    True),
        StructField("hist_rpt_acct_dt",   StringType(),    True),
    ])


# ── Row builders ──────────────────────────────────────────────────────────────
def build_summary_row(
    cons_acct_key: int,
    rpt_as_of_mo: str,
    base_ts: datetime,
    balance: Optional[float] = 1000.0,
    actual_payment: Optional[float] = 100.0,
    credit_limit: Optional[float] = 5000.0,
    past_due: Optional[float] = 0.0,
    days_past_due: Optional[int] = 0,
    payment_rating: Optional[str] = "0",
    asset_class: Optional[str] = "A",
    soft_del_cd: Optional[str] = None,
    balance_history: Optional[List] = None,
    payment_history: Optional[List] = None,
    credit_history: Optional[List] = None,
    past_due_history: Optional[List] = None,
    dpd_history: Optional[List] = None,
    rating_history: Optional[List] = None,
    asset_history: Optional[List] = None,
    payment_history_grid: Optional[str] = None,
    history_len: int = SUMMARY_HISTORY_LEN,
) -> Dict[str, Any]:
    def _h(v, slot_val):
        if v is not None:
            return v
        return history({0: slot_val}, length=history_len)

    return {
        "cons_acct_key":            int(cons_acct_key),
        "rpt_as_of_mo":             rpt_as_of_mo,
        "base_ts":                  base_ts,
        "balance_am":               balance,
        "actual_payment_am":        actual_payment,
        "credit_limit_am":          credit_limit,
        "past_due_am":              past_due,
        "days_past_due":            days_past_due,
        "payment_rating_cd":        payment_rating,
        "asset_class_cd_4in":       asset_class,
        "soft_del_cd":              soft_del_cd,
        "payment_history_grid":     payment_history_grid,
        "balance_am_history":        _h(balance_history, balance),
        "actual_payment_am_history": _h(payment_history, actual_payment),
        "credit_limit_am_history":   _h(credit_history, credit_limit),
        "past_due_am_history":       _h(past_due_history, past_due),
        "days_past_due_history":     _h(dpd_history, days_past_due),
        "payment_rating_cd_history": _h(rating_history, payment_rating),
        "asset_class_cd_4in_history": _h(asset_history, asset_class),
    }


def build_source_row(
    cons_acct_key: int,
    rpt_as_of_mo: str,
    base_ts: datetime,
    balance: Optional[float] = None,
    actual_payment: Optional[float] = None,
    credit_limit: Optional[float] = 5000.0,
    past_due: Optional[float] = 0.0,
    days_past_due: Optional[int] = 0,
    payment_rating: Optional[str] = "0",
    asset_class: Optional[str] = "A",
    soft_del_cd: Optional[str] = None,
    hist_rpt_acct_dt: Optional[str] = None,
) -> Dict[str, Any]:
    return {
        "cons_acct_key":      int(cons_acct_key),
        "rpt_as_of_mo":       rpt_as_of_mo,
        "base_ts":            base_ts,
        "balance_am":         balance,
        "actual_payment_am":  actual_payment,
        "credit_limit_am":    credit_limit,
        "past_due_am":        past_due,
        "days_past_due":      days_past_due,
        "payment_rating_cd":  payment_rating,
        "asset_class_cd_4in": asset_class,
        "soft_del_cd":        soft_del_cd,
        "hist_rpt_acct_dt":   hist_rpt_acct_dt,
    }


# ── Config factory ────────────────────────────────────────────────────────────
def make_config(
    namespace: str,
    history_length: int = SUMMARY_HISTORY_LEN,
    latest_history_window_months: int = LATEST_HISTORY_LEN,
) -> Dict[str, Any]:
    """Return a minimal but complete config dict for v5 pipeline."""
    return {
        "source_table":          f"prod_catalog.testdb.{namespace}_source",
        "destination_table":     f"prod_catalog.testdb.{namespace}_summary",
        "latest_history_table":  f"prod_catalog.testdb.{namespace}_latest_summary",
        "watermark_tracker_table": f"prod_catalog.testdb.{namespace}_tracker",
        "partition_column":      "rpt_as_of_mo",
        "primary_column":        "cons_acct_key",
        "primary_date_column":   "hist_rpt_acct_dt",
        "max_identifier_column": "base_ts",
        "history_length":        history_length,
        "latest_history_window_months": latest_history_window_months,
        "hist_rpt_dt_table":     f"prod_catalog.testdb.{namespace}_hist_rpt_dt",
        "hist_rpt_dt_cols":      ["cons_acct_key", "hist_rpt_acct_dt", "base_ts"],
        "columns": {
            "cons_acct_key":      "cons_acct_key",
            "rpt_as_of_mo":       "rpt_as_of_mo",
            "base_ts":            "base_ts",
            "balance_am":         "balance_am",
            "actual_payment_am":  "actual_payment_am",
            "credit_limit_am":    "credit_limit_am",
            "past_due_am":        "past_due_am",
            "days_past_due":      "days_past_due",
            "payment_rating_cd":  "payment_rating_cd",
            "asset_class_cd_4in": "asset_class_cd_4in",
            "soft_del_cd":        "soft_del_cd",
        },
        "column_transformations": [],
        "inferred_columns": [],
        "coalesce_exclusion_cols": ["soft_del_cd"],
        "date_col_list": ["hist_rpt_acct_dt"],
        "latest_history_addon_cols": [],
        "rolling_columns": [
            {"name": "balance_am",          "mapper_column": "balance_am",         "type": "DOUBLE"},
            {"name": "actual_payment_am",   "mapper_column": "actual_payment_am",  "type": "DOUBLE"},
            {"name": "credit_limit_am",     "mapper_column": "credit_limit_am",    "type": "DOUBLE"},
            {"name": "past_due_am",         "mapper_column": "past_due_am",        "type": "DOUBLE"},
            {"name": "days_past_due",       "mapper_column": "days_past_due",      "type": "INT"},
            {"name": "payment_rating_cd",   "mapper_column": "payment_rating_cd",  "type": "STRING"},
            {"name": "asset_class_cd_4in",  "mapper_column": "asset_class_cd_4in", "type": "STRING"},
        ],
        "grid_columns": [
            {
                "name": "payment_history_grid",
                "mapper_rolling_column": "payment_rating_cd",
                "placeholder": "?",
                "seperator": "",
            }
        ],
        "spark": {
            "app_name": f"test_{namespace}",
            "spark.sql.shuffle.partitions": "4",
        },
        # v5 feature flags
        "enable_case3_hot_cold_split":   True,
        "use_working_set_latest_context":    True,
        "use_working_set_case3_summary_context": True,
        "force_cold_case3_broadcast":    True,
        "cold_case3_broadcast_row_cap":  10_000_000,
        "case3_hot_window_months":       36,
        "validate_latest_history_window": True,
    }


# ── Table write / read helpers ────────────────────────────────────────────────
def _ensure_namespace(spark: SparkSession, table: str) -> None:
    ns = table.rsplit(".", 1)[0]
    spark.sql(f"CREATE NAMESPACE IF NOT EXISTS {ns}")


def write_rows(spark: SparkSession, table: str, rows: List[Dict[str, Any]]) -> None:
    """Write rows to a table, creating or replacing it."""
    if not rows:
        return
    _ensure_namespace(spark, table)
    df = spark.createDataFrame(rows)
    df.writeTo(table).createOrReplace()


def write_summary_rows(spark: SparkSession, table: str, rows: List[Dict[str, Any]]) -> None:
    write_rows(spark, table, rows)


def write_source_rows(spark: SparkSession, table: str, rows: List[Dict[str, Any]]) -> None:
    write_rows(spark, table, rows)


def reset_tables(spark: SparkSession, config: Dict[str, Any]) -> None:
    """Drop source, summary, latest_summary, and tracker tables."""
    for key in ("source_table", "destination_table", "latest_history_table", "watermark_tracker_table"):
        tbl = config.get(key, "")
        if tbl:
            spark.sql(f"DROP TABLE IF EXISTS {tbl}")


def fetch_single_row(
    spark: SparkSession,
    table: str,
    key: int,
    month: str,
) -> Dict[str, Any]:
    """Return the single row for (key, month) or raise AssertionError."""
    rows = (
        spark.table(table)
        .filter((F.col("cons_acct_key") == key) & (F.col("rpt_as_of_mo") == month))
        .collect()
    )
    if len(rows) != 1:
        raise AssertionError(
            f"Expected exactly 1 row for key={key} month={month} in {table}, got {len(rows)}"
        )
    return rows[0].asDict(recursive=True)


def fetch_rows(
    spark: SparkSession,
    table: str,
    key: int,
) -> List[Dict[str, Any]]:
    return [
        r.asDict(recursive=True)
        for r in spark.table(table).filter(F.col("cons_acct_key") == key).collect()
    ]
